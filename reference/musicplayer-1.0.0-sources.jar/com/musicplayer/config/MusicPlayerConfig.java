package com.musicplayer.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Manages persistent configuration for the Music Player mod.
 * Stores music folder path, volume, last played song, and playback mode.
 */
public class MusicPlayerConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("musicplayer.json");

    private static MusicPlayerConfig instance;

    // Config fields
    private String musicFolderPath = "";
    private float volume = 0.75f;
    private float masterVolume = 1.0f;
    private String lastPlayedSong = "";
    private PlaybackMode playbackMode = PlaybackMode.SEQUENTIAL;
    private NowPlayingStyle nowPlayingStyle = NowPlayingStyle.WIDGET;

    // Fade settings
    private boolean fadeInEnabled = false;
    private float fadeInDuration = 2.0f;
    private boolean fadeOutEnabled = false;
    private float fadeOutDuration = 2.0f;

    // Ducking settings
    private boolean duckingEnabled = false;
    private float duckingDuration = 2.0f;

    // Singleplayer pause setting
    private boolean pauseOnGamePause = false;
    private boolean pauseOnLostFocus = false;

    // GUI scale factor (default 1.0f)
    private float guiScale = 1.0f;

    public enum NowPlayingStyle { WIDGET, HOTBAR_TEXT }

    public enum PlaybackMode {
        SEQUENTIAL,
        SHUFFLE,
        REPEAT_ALL,
        REPEAT_ONE
    }

    private MusicPlayerConfig() {}

    public static MusicPlayerConfig getInstance() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    /**
     * Loads config from disk, or returns defaults if file doesn't exist.
     */
    private static MusicPlayerConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                String json = Files.readString(CONFIG_PATH);
                MusicPlayerConfig config = GSON.fromJson(json, MusicPlayerConfig.class);
                if (config != null) {
                    return config;
                }
            } catch (IOException e) {
                System.err.println("[MusicPlayer] Failed to load config: " + e.getMessage());
            }
        }
        return new MusicPlayerConfig();
    }

    /**
     * Saves the current config to disk.
     */
    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[MusicPlayer] Failed to save config: " + e.getMessage());
        }
    }

    // --- Getters and Setters ---

    public String getMusicFolderPath() {
        return musicFolderPath;
    }

    public void setMusicFolderPath(String path) {
        this.musicFolderPath = path;
        save();
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float volume) {
        this.volume = Math.max(0f, Math.min(1f, volume));
        save();
    }

    public float getMasterVolume() {
        return masterVolume;
    }

    public void setMasterVolume(float masterVolume) {
        this.masterVolume = Math.max(0f, Math.min(1f, masterVolume));
        save();
        com.musicplayer.MusicPlayerManager.getInstance().getEngine().updateMasterVolume();
    }

    public String getLastPlayedSong() {
        return lastPlayedSong;
    }

    public void setLastPlayedSong(String songName) {
        this.lastPlayedSong = songName;
        save();
    }

    public PlaybackMode getPlaybackMode() {
        return playbackMode;
    }

    public void setPlaybackMode(PlaybackMode mode) {
        this.playbackMode = mode;
        save();
    }

    public NowPlayingStyle getNowPlayingStyle() {
        return nowPlayingStyle;
    }

    public void setNowPlayingStyle(NowPlayingStyle style) {
        this.nowPlayingStyle = style;
        save();
    }

    public boolean isFadeInEnabled() { return fadeInEnabled; }
    public void setFadeInEnabled(boolean val) { this.fadeInEnabled = val; save(); }
    public float getFadeInDuration() { return fadeInDuration; }
    public void setFadeInDuration(float val) { this.fadeInDuration = val; save(); }
    
    public boolean isFadeOutEnabled() { return fadeOutEnabled; }
    public void setFadeOutEnabled(boolean val) { this.fadeOutEnabled = val; save(); }
    public float getFadeOutDuration() { return fadeOutDuration; }
    public void setFadeOutDuration(float val) { this.fadeOutDuration = val; save(); }

    public boolean isDuckingEnabled() { return duckingEnabled; }
    public void setDuckingEnabled(boolean val) { this.duckingEnabled = val; save(); }
    public float getDuckingDuration() { return duckingDuration; }
    public void setDuckingDuration(float val) { this.duckingDuration = val; save(); }

    public boolean isPauseOnGamePause() { return pauseOnGamePause; }
    public void setPauseOnGamePause(boolean val) { this.pauseOnGamePause = val; save(); }

    public boolean isPauseOnLostFocus() { return pauseOnLostFocus; }
    public void setPauseOnLostFocus(boolean val) { this.pauseOnLostFocus = val; save(); }

    public float getGuiScale() { return guiScale; }
    public void setGuiScale(float scale) { this.guiScale = Math.max(0.8f, Math.min(2.0f, scale)); save(); }
}
