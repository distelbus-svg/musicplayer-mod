package com.musicplayer;

import com.musicplayer.config.MusicPlayerConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import com.musicplayer.widget.SettingsSliderWidget;

/**
 * General settings sub-screen.
 * Redesigned with category sections for Playback and Extras.
 */
public class GeneralSettingsScreen extends ScaledScreen {

    private final Screen parent;
    private final MusicPlayerManager manager;

    public GeneralSettingsScreen(Screen parent) {
        super(Component.literal("General Settings"));
        this.parent = parent;
        this.manager = MusicPlayerManager.getInstance();
    }

    @Override
    protected void initScaled() {
        int centerX = this.width / 2;
        int panelWidth = 300;
        int panelLeft = centerX - panelWidth / 2;
        int panelTop = this.height / 2 - 150;

        // --- Playback Section ---
        int y = panelTop + 37;

        // Now Playing Style toggle
        addRenderableWidget(Button.builder(
                Component.literal("Now Playing: " + getNowPlayingStyleName(manager.getConfig().getNowPlayingStyle())),
                button -> {
                    MusicPlayerConfig.NowPlayingStyle current = manager.getConfig().getNowPlayingStyle();
                    MusicPlayerConfig.NowPlayingStyle next = current == MusicPlayerConfig.NowPlayingStyle.WIDGET
                            ? MusicPlayerConfig.NowPlayingStyle.HOTBAR_TEXT
                            : MusicPlayerConfig.NowPlayingStyle.WIDGET;
                    manager.getConfig().setNowPlayingStyle(next);
                    button.setMessage(Component.literal("Now Playing: " + getNowPlayingStyleName(next)));
                }
        ).bounds(panelLeft + 10, y, panelWidth - 20, 20).build());

        y += 22;

        // Fade In Toggle
        addRenderableWidget(Button.builder(
                Component.literal("Fade In: " + (manager.getConfig().isFadeInEnabled() ? "ON" : "OFF")),
                button -> {
                    boolean next = !manager.getConfig().isFadeInEnabled();
                    manager.getConfig().setFadeInEnabled(next);
                    button.setMessage(Component.literal("Fade In: " + (next ? "ON" : "OFF")));
                }
        ).bounds(panelLeft + 10, y, 100, 20).build());

        // Fade In Duration Slider
        addRenderableWidget(new SettingsSliderWidget(
                panelLeft + 115, y, panelWidth - 125, 20,
                "Duration", "s",
                0.5f, 5.0f, manager.getConfig().getFadeInDuration(),
                "Fade In",
                val -> manager.getConfig().setFadeInDuration(val)
        ));

        y += 22;

        // Fade Out Toggle
        addRenderableWidget(Button.builder(
                Component.literal("Fade Out: " + (manager.getConfig().isFadeOutEnabled() ? "ON" : "OFF")),
                button -> {
                    boolean next = !manager.getConfig().isFadeOutEnabled();
                    manager.getConfig().setFadeOutEnabled(next);
                    button.setMessage(Component.literal("Fade Out: " + (next ? "ON" : "OFF")));
                }
        ).bounds(panelLeft + 10, y, 100, 20).build());

        // Fade Out Duration Slider
        addRenderableWidget(new SettingsSliderWidget(
                panelLeft + 115, y, panelWidth - 125, 20,
                "Duration", "s",
                0.5f, 5.0f, manager.getConfig().getFadeOutDuration(),
                "Fade Out",
                val -> manager.getConfig().setFadeOutDuration(val)
        ));

        y += 22;

        // Pause music when game unfocused Toggle
        addRenderableWidget(Button.builder(
                Component.literal("Pause music when game unfocused: " + (manager.getConfig().isPauseOnLostFocus() ? "ON" : "OFF")),
                button -> {
                    boolean next = !manager.getConfig().isPauseOnLostFocus();
                    manager.getConfig().setPauseOnLostFocus(next);
                    button.setMessage(Component.literal("Pause music when game unfocused: " + (next ? "ON" : "OFF")));
                }
        ).bounds(panelLeft + 10, y, panelWidth - 20, 20).build());

        // --- Extras Section ---
        y = panelTop + 143;

        // pause singleplayer when in player Toggle
        addRenderableWidget(Button.builder(
                Component.literal("pause singleplayer when in player: " + (manager.getConfig().isPauseOnGamePause() ? "ON" : "OFF")),
                button -> {
                    boolean next = !manager.getConfig().isPauseOnGamePause();
                    manager.getConfig().setPauseOnGamePause(next);
                    button.setMessage(Component.literal("pause singleplayer when in player: " + (next ? "ON" : "OFF")));
                }
        ).bounds(panelLeft + 10, y, panelWidth - 20, 20).build());

        y += 22;

        // Ducking Toggle
        addRenderableWidget(Button.builder(
                Component.literal("Damage Ducking: " + (manager.getConfig().isDuckingEnabled() ? "ON" : "OFF")),
                button -> {
                    boolean next = !manager.getConfig().isDuckingEnabled();
                    manager.getConfig().setDuckingEnabled(next);
                    button.setMessage(Component.literal("Damage Ducking: " + (next ? "ON" : "OFF")));
                }
        ).bounds(panelLeft + 10, y, 100, 20).build());

        // Ducking Duration Slider
        addRenderableWidget(new SettingsSliderWidget(
                panelLeft + 115, y, panelWidth - 125, 20,
                "Duration", "s",
                0.5f, 5.0f, manager.getConfig().getDuckingDuration(),
                "Ducking",
                val -> manager.getConfig().setDuckingDuration(val)
        ));

        // Done button at bottom
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> {
            this.onClose();
        }).bounds(centerX - 50, panelTop + 265, 100, 20).build());
    }

    @Override
    public void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0xC0000000);

        int centerX = this.width / 2;
        int panelWidth = 300;
        int panelLeft = centerX - panelWidth / 2;
        int panelTop = this.height / 2 - 150;
        int panelBottom = panelTop + 295;

        // Panel background & border
        graphics.fill(panelLeft - 2, panelTop - 2, panelLeft + panelWidth + 2, panelBottom + 2, 0xFF555555);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelBottom, 0xFF2D2D2D);

        // Screen title
        graphics.centeredText(this.font, this.title, centerX, panelTop + 8, 0xFFFFFFFF);

        // Section header rendering
        graphics.centeredText(this.font, "--- Playback ---", centerX, panelTop + 25, 0xFFFFAA00);
        graphics.centeredText(this.font, "--- Extras ---", centerX, panelTop + 131, 0xFFFFAA00);

        super.renderScaled(graphics, mouseX, mouseY, partialTick);
    }

    private String getNowPlayingStyleName(MusicPlayerConfig.NowPlayingStyle style) {
        if (style == MusicPlayerConfig.NowPlayingStyle.HOTBAR_TEXT) {
            return "Hotbar Text";
        }
        return "Widget";
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
