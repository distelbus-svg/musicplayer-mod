package com.musicplayer.widget;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

public class SettingsSliderWidget extends AbstractWidget {
    private static final int BG_COLOR = 0xFF000000;
    private static final int FILL_COLOR = 0xFFAAAAAA;
    private static final int BORDER_COLOR = 0xFFFFFFFF;
    private static final int KNOB_COLOR = 0xFFFFFFFF;

    private boolean dragging = false;
    private float value; // 0.0 to 1.0
    private final float minVal;
    private final float maxVal;
    private final String prefix;
    private final String suffix;
    private final Consumer<Float> onValueChanged;

    private String description = null;

    public SettingsSliderWidget(int x, int y, int width, int height, String prefix, String suffix, float minVal, float maxVal, float initialVal, Consumer<Float> onValueChanged) {
        this(x, y, width, height, prefix, suffix, minVal, maxVal, initialVal, null, onValueChanged);
    }

    public SettingsSliderWidget(int x, int y, int width, int height, String prefix, String suffix, float minVal, float maxVal, float initialVal, String description, Consumer<Float> onValueChanged) {
        super(x, y, width, height, Component.empty());
        this.prefix = prefix;
        this.suffix = suffix;
        this.minVal = minVal;
        this.maxVal = maxVal;
        this.value = (initialVal - minVal) / (maxVal - minVal);
        this.description = description;
        this.onValueChanged = onValueChanged;
    }

    @Override
    protected void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), BORDER_COLOR);
        graphics.fill(getX() + 1, getY() + 1, getX() + getWidth() - 1, getY() + getHeight() - 1, BG_COLOR);

        int fillWidth = (int) ((getWidth() - 2) * value);
        if (fillWidth > 0) {
            graphics.fill(getX() + 1, getY() + 1, getX() + 1 + fillWidth, getY() + getHeight() - 1, FILL_COLOR);
        }

        int knobX = getX() + 1 + fillWidth;
        graphics.fill(Math.max(getX() + 1, knobX - 1), getY(), Math.min(getX() + getWidth() - 1, knobX + 2), getY() + getHeight(), KNOB_COLOR);

        float actualVal = minVal + value * (maxVal - minVal);
        String text = String.format("%s: %.1f%s", prefix, actualVal, suffix);
        if (description != null && !description.isEmpty()) {
            int textWidth = Minecraft.getInstance().font.width(text);
            graphics.text(Minecraft.getInstance().font, text, getX() + (getWidth() - textWidth) / 2, getY() + 2, 0xFFFFFFFF, true);
            
            int descWidth = Minecraft.getInstance().font.width(description);
            graphics.text(Minecraft.getInstance().font, description, getX() + (getWidth() - descWidth) / 2, getY() + 11, 0x80A0A0A0, true);
        } else {
            int textWidth = Minecraft.getInstance().font.width(text);
            graphics.text(Minecraft.getInstance().font, text, getX() + (getWidth() - textWidth) / 2, getY() + (getHeight() - 8) / 2, 0xFFFFFFFF, true);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean isFocused) {
        if (event.buttonInfo().button() == 0 && this.isHovered()) {
            dragging = true;
            setValueFromMouse(event.x());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging && event.buttonInfo().button() == 0) {
            setValueFromMouse(event.x());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.buttonInfo().button() == 0 && dragging) {
            dragging = false;
            return true;
        }
        return false;
    }

    private void setValueFromMouse(double mouseX) {
        this.value = (float) (mouseX - getX()) / getWidth();
        this.value = Math.max(0f, Math.min(1f, this.value));
        float actualVal = minVal + value * (maxVal - minVal);
        onValueChanged.accept(actualVal);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {}
}
