package com.musicplayer.widget;

import com.musicplayer.config.MusicPlayerConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class MusicPlayerSliderWidget extends AbstractWidget {

    private static final int BG_COLOR = 0xFF000000;
    private static final int FILL_COLOR = 0xFFAAAAAA;
    private static final int BORDER_COLOR = 0xFFFFFFFF;
    private static final int KNOB_COLOR = 0xFFFFFFFF;

    private boolean dragging = false;

    public MusicPlayerSliderWidget(int x, int y, int width, int height) {
        super(x, y, width, height, Component.literal("Music Player"));
    }

    @Override
    protected void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        float volume = MusicPlayerConfig.getInstance().getMasterVolume();

        // Border
        graphics.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), BORDER_COLOR);
        // Background
        graphics.fill(getX() + 1, getY() + 1, getX() + getWidth() - 1, getY() + getHeight() - 1, BG_COLOR);

        // Fill
        int fillWidth = (int) ((getWidth() - 2) * volume);
        if (fillWidth > 0) {
            graphics.fill(
                    getX() + 1, getY() + 1,
                    getX() + 1 + fillWidth, getY() + getHeight() - 1,
                    FILL_COLOR
            );
        }

        // Knob
        int knobX = getX() + 1 + fillWidth;
        graphics.fill(
                Math.max(getX() + 1, knobX - 1), getY(),
                Math.min(getX() + getWidth() - 1, knobX + 2), getY() + getHeight(),
                KNOB_COLOR
        );

        int percent = Math.round(volume * 100);
        String text = "Music Player: " + percent + "%";
        int textWidth = Minecraft.getInstance().font.width(text);
        graphics.text(
                Minecraft.getInstance().font,
                text,
                getX() + (getWidth() - textWidth) / 2,
                getY() + (getHeight() - 8) / 2,
                0xFFFFFF, true
        );
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean isFocused) {
        if (event.buttonInfo().button() == 0 && this.isHovered()) {
            dragging = true;
            setVolumeFromMouse(event.x());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging && event.buttonInfo().button() == 0) {
            setVolumeFromMouse(event.x());
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.buttonInfo().button() == 0 && dragging) {
            dragging = false;
            return true;
        }
        return false;
    }

    private void setVolumeFromMouse(double mouseX) {
        float vol = (float) (mouseX - getX()) / getWidth();
        vol = Math.max(0f, Math.min(1f, vol));
        MusicPlayerConfig.getInstance().setMasterVolume(vol);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
    }
}
