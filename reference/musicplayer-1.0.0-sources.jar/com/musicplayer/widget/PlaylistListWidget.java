package com.musicplayer.widget;

import com.musicplayer.Playlist;
import com.musicplayer.PlaylistManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.network.chat.Component;

import java.util.List;

public class PlaylistListWidget extends ObjectSelectionList<PlaylistListWidget.PlaylistEntry> {

    public PlaylistListWidget(Minecraft minecraft, int width, int height, int y, int itemHeight) {
        super(minecraft, width, height, y, itemHeight);
    }

    public void refreshEntries(PlaylistAction playAction, PlaylistAction editAction, PlaylistAction deleteAction) {
        this.clearEntries();
        List<Playlist> playlists = PlaylistManager.getInstance().getPlaylists();
        for (Playlist playlist : playlists) {
            this.addEntry(new PlaylistEntry(playlist, playAction, editAction, deleteAction));
        }
    }

    public class PlaylistEntry extends ObjectSelectionList.Entry<PlaylistEntry> {
        private final Playlist playlist;
        private final PlaylistAction playAction;
        private final PlaylistAction editAction;
        private final PlaylistAction deleteAction;

        public PlaylistEntry(Playlist playlist, PlaylistAction playAction, PlaylistAction editAction, PlaylistAction deleteAction) {
            this.playlist = playlist;
            this.playAction = playAction;
            this.editAction = editAction;
            this.deleteAction = deleteAction;
        }

        @Override
        public Component getNarration() {
            return Component.literal(playlist.getName());
        }

        @Override
        public void extractContent(GuiGraphicsExtractor graphics, int entryIndex, int top, boolean isSelected, float partialTick) {
            int x = this.getX();
            int y = this.getY();
            int width = this.getWidth();
            int height = this.getHeight();

            // Background
            int bgColor = isSelected ? 0x60FFFFFF : (entryIndex % 2 == 0 ? 0x30000000 : 0x20000000);
            graphics.fill(x, y, x + width, y + height, bgColor);

            // Name
            String name = playlist.getName();
            int maxWidth = width - 110;
            if (Minecraft.getInstance().font.width(name) > maxWidth) {
                name = Minecraft.getInstance().font.plainSubstrByWidth(name, maxWidth - 10) + "...";
            }
            graphics.text(Minecraft.getInstance().font, name, x + 4, y + 4, 0xFFFFFFFF, true);

            // Info
            String info = playlist.getSongs().size() + " songs";
            graphics.text(Minecraft.getInstance().font, info, x + width - 100, y + 4, 0xFFAAAAAA, true);

            // Buttons hint (simplified)
            graphics.text(Minecraft.getInstance().font, "Play | Edit | Del", x + width - 85, y + 14, 0xFF888888, true);
        }

        @Override
        public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean isFocused) {
            if (event.buttonInfo().button() == 0) {
                double relativeX = event.x() - this.getX();
                if (relativeX > this.getWidth() - 30) {
                    deleteAction.run(playlist);
                } else if (relativeX > this.getWidth() - 60) {
                    editAction.run(playlist);
                } else {
                    playAction.run(playlist);
                }
                return true;
            }
            return false;
        }
    }

    @FunctionalInterface
    public interface PlaylistAction {
        void run(Playlist playlist);
    }
}
