package com.musicplayer.widget;

import com.musicplayer.MusicPlayerManager;
import com.musicplayer.SongInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.io.File;
import java.util.List;
import java.util.function.Predicate;

/**
 * A scrollable list widget that displays songs.
 */
public class SongListWidget extends ObjectSelectionList<SongListWidget.SongEntry> {

    private final MusicPlayerManager manager;
    private SongAction onSelect = null;
    private Predicate<SongInfo> checkboxStateProvider = null;

    public SongListWidget(Minecraft minecraft, int width, int height, int y, int itemHeight) {
        super(minecraft, width, height, y, itemHeight);
        this.manager = MusicPlayerManager.getInstance();
    }

    public void setOnSelect(SongAction onSelect) {
        this.onSelect = onSelect;
    }

    public void setCheckboxStateProvider(Predicate<SongInfo> provider) {
        this.checkboxStateProvider = provider;
    }

    public void setSongs(List<SongInfo> songs) {
        this.clearEntries();
        for (int i = 0; i < songs.size(); i++) {
            addEntry(new SongEntry(songs.get(i), i));
        }
    }

    public void addSong(SongInfo song) {
        addEntry(new SongEntry(song, getItemCount()));
    }

    @Override
    public int getRowWidth() {
        return this.width - 20;
    }

    @Override
    protected int scrollBarX() {
        return this.getX() + this.width - 6;
    }

    public class SongEntry extends ObjectSelectionList.Entry<SongEntry> {
        private final SongInfo song;
        private final int index;

        public SongEntry(SongInfo song, int index) {
            this.song = song;
            this.index = index;
        }

        @Override
        public Component getNarration() {
            return Component.literal(song.getTitle());
        }

        @Override
        public void extractContent(GuiGraphicsExtractor graphics, int entryIndex, int top, boolean isSelected, float partialTick) {
            int left = this.getX();
            int y = this.getY();
            int entryWidth = this.getWidth();
            int entryHeight = this.getHeight();
            
            // Check if this song is the one currently playing in manager
            boolean isPlaying = false;
            if (manager.getCurrentSong() != null && manager.getCurrentSong().getPath().equals(song.getPath())) {
                isPlaying = manager.getEngine().isActive();
            }
            
            boolean hovered = SongListWidget.this.getHovered() == this;

            int bgColor;
            if (isPlaying) {
                bgColor = 0x6000AA00;
            } else if (isSelected || hovered) {
                bgColor = 0x60FFFFFF;
            } else if (entryIndex % 2 == 0) {
                bgColor = 0x30000000;
            } else {
                bgColor = 0x20000000;
            }
            graphics.fill(left, y, left + entryWidth, y + entryHeight, bgColor);

            String prefix = isPlaying ? "\u25B6 " : (song.getSource() == SongInfo.SourceType.YOUTUBE ? "\u25B7 " : "   ");
            int textColor = isPlaying ? 0xFF55FF55 : (song.getSource() == SongInfo.SourceType.YOUTUBE ? 0xFFFF5555 : 0xFFFFFFFF);

            int textLeft = left + 4;
            if (checkboxStateProvider != null) {
                boolean checked = checkboxStateProvider.test(song);
                graphics.fill(left + 4, y + 2, left + 12, y + 10, 0xFFFFFFFF);
                if (checked) {
                    graphics.fill(left + 5, y + 3, left + 11, y + 9, 0xFF00AA00);
                } else {
                    graphics.fill(left + 5, y + 3, left + 11, y + 9, 0xFF000000);
                }
                textLeft += 12;
            }

            graphics.text(
                    Minecraft.getInstance().font,
                    prefix + song.getTitle(),
                    textLeft, y + 2,
                    textColor, true
            );

            String subText = song.getArtist();
            if (subText != null) {
                int subWidth = Minecraft.getInstance().font.width(subText);
                graphics.text(
                        Minecraft.getInstance().font,
                        subText,
                        left + entryWidth - subWidth - 20, y + 2,
                        0xFFAAAAAA, true
                );
            }
        }

        @Override
        public boolean mouseClicked(MouseButtonEvent event, boolean isFocused) {
            if (event.buttonInfo().button() == 0) {
                SongListWidget.this.setSelected(this);
                if (onSelect != null) {
                    onSelect.run(song, index);
                } else {
                    manager.playSong(index);
                }
                return true;
            }
            return false;
        }

        public SongInfo getSong() {
            return song;
        }
    }

    @FunctionalInterface
    public interface SongAction {
        void run(SongInfo song, int index);
    }
}
