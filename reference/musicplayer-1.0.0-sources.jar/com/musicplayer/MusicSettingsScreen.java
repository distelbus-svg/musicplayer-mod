package com.musicplayer;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Top-level settings screen that links to category sub-screens.
 */
public class MusicSettingsScreen extends ScaledScreen {

    private final Screen parent;

    public MusicSettingsScreen(Screen parent) {
        super(Component.literal("Music Player Settings"));
        this.parent = parent;
    }

    @Override
    protected void initScaled() {
        int centerX = this.width / 2;
        int panelWidth = 280;
        int panelLeft = centerX - panelWidth / 2;
        int panelTop = this.height / 2 - 70;
        int y = panelTop + 35;

        // Music Folder button
        addRenderableWidget(Button.builder(Component.literal("Set Music Folder Path"), button -> {
            this.minecraft.setScreen(new MusicFolderScreen(this));
        }).bounds(panelLeft + 40, y, 200, 20).build());

        y += 25;

        // General Settings button
        addRenderableWidget(Button.builder(Component.literal("General Settings"), button -> {
            this.minecraft.setScreen(new GeneralSettingsScreen(this));
        }).bounds(panelLeft + 40, y, 200, 20).build());

        y += 25;

        // Listening Statistics button
        addRenderableWidget(Button.builder(Component.literal("Listening Statistics"), button -> {
            this.minecraft.setScreen(new ListeningStatisticsScreen(this));
        }).bounds(panelLeft + 40, y, 200, 20).build());

        y += 25;

        // Resize Menu button
        addRenderableWidget(Button.builder(Component.literal("Resize Menu"), button -> {
            this.minecraft.setScreen(new ResizeMenuScreen(this));
        }).bounds(panelLeft + 40, y, 200, 20).build());

        // Done button
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> {
            this.onClose();
        }).bounds(centerX - 50, panelTop + 140, 100, 20).build());
    }

    @Override
    public void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0xC0000000);

        int centerX = this.width / 2;
        int panelWidth = 280;
        int panelLeft = centerX - panelWidth / 2;
        int panelTop = this.height / 2 - 80;
        int panelBottom = panelTop + 175;

        // Panel background
        graphics.fill(panelLeft - 2, panelTop - 2, panelLeft + panelWidth + 2, panelBottom + 2, 0xFF555555);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelBottom, 0xFF2D2D2D);

        // Title
        graphics.centeredText(this.font, this.title, centerX, panelTop + 8, 0xFFFFFFFF);

        super.renderScaled(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
