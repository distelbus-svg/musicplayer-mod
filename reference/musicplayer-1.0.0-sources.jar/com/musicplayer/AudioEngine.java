package com.musicplayer;

import javazoom.jl.decoder.*;
import javax.sound.sampled.*;
import java.io.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class AudioEngine {

    private SourceDataLine line;
    private Thread playbackThread;
    private final AtomicBoolean playing = new AtomicBoolean(false);
    private final AtomicBoolean paused = new AtomicBoolean(false);
    private final AtomicBoolean stopRequested = new AtomicBoolean(false);

    private volatile boolean manualPauseRequested = false;
    private volatile boolean isFadingInForUnpause = false;
    private volatile long fadeStartMs = 0;
    private volatile long fadeDurationMs = 0;
    
    private volatile boolean isDucking = false;
    private volatile long duckStartTimeMs = 0;

    private String currentTrackPath = null;
    private net.minecraft.client.resources.sounds.SimpleSoundInstance currentSoundInstance;
    private volatile boolean isMinecraftSoundPlaying = false;

    private float volume = 1.0f;
    private volatile float fadeVolume = 1.0f;
    private long durationMs = 0;
    private volatile long positionMs = 0;
    private Runnable onFinished;
    private Runnable onTrackStart;

    public void setOnFinished(Runnable onFinished) {
        this.onFinished = onFinished;
    }

    public void setOnTrackStart(Runnable onTrackStart) {
        this.onTrackStart = onTrackStart;
    }

    public void play(File file, long seekToMs) {
        stop();
        stopRequested.set(false);
        playing.set(true);
        paused.set(false);
        manualPauseRequested = false;
        isFadingInForUnpause = false;
        currentTrackPath = file.getAbsolutePath();
        
        if (onTrackStart != null) {
            onTrackStart.run();
        }

        playbackThread = new Thread(() -> {
            try {
                if (file.getName().toLowerCase().endsWith(".mp3")) {
                    playMp3(file, seekToMs);
                } else if (file.getName().toLowerCase().endsWith(".wav")) {
                    playWav(file, seekToMs);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                playing.set(false);
                if (!stopRequested.get() && onFinished != null) {
                    onFinished.run();
                }
            }
        }, "MusicPlaybackThread");
        playbackThread.start();
    }

    private void playMp3(File file, long seekToMs) throws Exception {
        FileInputStream fis = new FileInputStream(file);
        Bitstream bitstream = new Bitstream(fis);
        Decoder decoder = new Decoder();

        // Approximate duration (not perfect for VBR)
        durationMs = estimateMp3Duration(file);
        
        // Seeking
        if (seekToMs > 0) {
            long currentMs = 0;
            while (currentMs < seekToMs) {
                Header h = bitstream.readFrame();
                if (h == null) break;
                currentMs += h.ms_per_frame();
                bitstream.closeFrame();
            }
            positionMs = currentMs;
        } else {
            positionMs = 0;
        }

        Header header = bitstream.readFrame();
        if (header == null) return;

        AudioFormat format = new AudioFormat(header.frequency(), 16, header.mode() == Header.SINGLE_CHANNEL ? 1 : 2, true, false);
        line = AudioSystem.getSourceDataLine(format);
        line.open(format);
        if (com.musicplayer.config.MusicPlayerConfig.getInstance().isFadeInEnabled() && seekToMs == 0) {
            applyVolume(0.0f);
        } else {
            applyVolume(1.0f);
        }
        line.start();

        while (header != null && !stopRequested.get()) {
            if (paused.get()) {
                Thread.sleep(50);
                continue;
            }

            applyPerTickFade();

            SampleBuffer output = (SampleBuffer) decoder.decodeFrame(header, bitstream);
            short[] buffer = output.getBuffer();
            byte[] bytes = new byte[output.getBufferLength() * 2];
            for (int i = 0; i < output.getBufferLength(); i++) {
                bytes[i * 2] = (byte) (buffer[i] & 0xFF);
                bytes[i * 2 + 1] = (byte) ((buffer[i] >> 8) & 0xFF);
            }

            line.write(bytes, 0, bytes.length);
            positionMs += header.ms_per_frame();
            bitstream.closeFrame();
            header = bitstream.readFrame();
        }

        line.drain();
        line.close();
        bitstream.close();
    }

    private void playWav(File file, long seekToMs) throws Exception {
        AudioInputStream ais = AudioSystem.getAudioInputStream(file);
        AudioFormat format = ais.getFormat();
        line = AudioSystem.getSourceDataLine(format);
        line.open(format);
        if (com.musicplayer.config.MusicPlayerConfig.getInstance().isFadeInEnabled() && seekToMs == 0) {
            applyVolume(0.0f);
        } else {
            applyVolume(1.0f);
        }
        line.start();

        durationMs = ais.getFrameLength() * 1000 / (long) format.getFrameRate();

        if (seekToMs > 0) {
            long bytesToSkip = (seekToMs * format.getFrameSize() * (long) format.getFrameRate()) / 1000;
            ais.skip(bytesToSkip);
            positionMs = seekToMs;
        } else {
            positionMs = 0;
        }

        byte[] buffer = new byte[4096];
        int n;
        long startTime = System.currentTimeMillis() - positionMs;

        while ((n = ais.read(buffer)) != -1 && !stopRequested.get()) {
            if (paused.get()) {
                Thread.sleep(50);
                startTime = System.currentTimeMillis() - positionMs; // Offset start time
                continue;
            }
            
            applyPerTickFade();

            line.write(buffer, 0, n);
            positionMs = System.currentTimeMillis() - startTime;
        }

        line.drain();
        line.close();
        ais.close();
    }

    public void stop() {
        stopRequested.set(true);
        if (line != null) {
            line.stop();
            line.flush();
        }
        if (isMinecraftSoundPlaying) {
            isMinecraftSoundPlaying = false;
            net.minecraft.client.Minecraft.getInstance().execute(() -> {
                if (currentSoundInstance != null) {
                    net.minecraft.client.Minecraft.getInstance().getSoundManager().stop(currentSoundInstance);
                    currentSoundInstance = null;
                }
            });
        }
        if (playbackThread != null) {
            try {
                playbackThread.join(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void togglePause() {
        com.musicplayer.config.MusicPlayerConfig config = com.musicplayer.config.MusicPlayerConfig.getInstance();
        
        if (manualPauseRequested) {
            manualPauseRequested = false;
            paused.set(false);
            if (config.isFadeInEnabled()) {
                isFadingInForUnpause = true;
                fadeStartMs = System.currentTimeMillis();
                fadeDurationMs = (long)(config.getFadeInDuration() * 1000);
                applyVolume(0.0f);
            } else {
                applyVolume(1.0f);
            }
            if (line != null) line.start();
            if (isMinecraftSoundPlaying) {
                net.minecraft.client.Minecraft.getInstance().execute(() -> {
                    if (currentSoundInstance != null) {
                        net.minecraft.client.Minecraft.getInstance().getSoundManager().stop(currentSoundInstance);
                    }
                    net.minecraft.resources.Identifier soundId = net.minecraft.resources.Identifier.parse(currentTrackPath);
                    net.minecraft.sounds.SoundEvent soundEvent = net.minecraft.core.registries.BuiltInRegistries.SOUND_EVENT.get(soundId)
                            .map(net.minecraft.core.Holder::value)
                            .orElse(null);
                    if (soundEvent == null) {
                        soundEvent = net.minecraft.sounds.SoundEvent.createVariableRangeEvent(soundId);
                    }
                    currentSoundInstance = new com.musicplayer.ModSoundInstance(soundEvent);
                    net.minecraft.client.Minecraft.getInstance().getSoundManager().play(currentSoundInstance);
                });
            }
            return;
        }

        if (!paused.get()) {
            if (config.isFadeOutEnabled()) {
                manualPauseRequested = true;
                fadeStartMs = System.currentTimeMillis();
                fadeDurationMs = (long)(config.getFadeOutDuration() * 1000);
            } else {
                paused.set(true);
                if (line != null) line.stop();
                if (isMinecraftSoundPlaying) {
                    net.minecraft.client.Minecraft.getInstance().execute(() -> {
                        if (currentSoundInstance != null) {
                            net.minecraft.client.Minecraft.getInstance().getSoundManager().stop(currentSoundInstance);
                        }
                    });
                }
            }
        } else {
            paused.set(false);
            if (config.isFadeInEnabled()) {
                isFadingInForUnpause = true;
                fadeStartMs = System.currentTimeMillis();
                fadeDurationMs = (long)(config.getFadeInDuration() * 1000);
                applyVolume(0.0f);
            } else {
                applyVolume(1.0f);
            }
            if (line != null) line.start();
            if (isMinecraftSoundPlaying) {
                net.minecraft.client.Minecraft.getInstance().execute(() -> {
                    if (currentSoundInstance != null) {
                        net.minecraft.client.Minecraft.getInstance().getSoundManager().stop(currentSoundInstance);
                    }
                    net.minecraft.resources.Identifier soundId = net.minecraft.resources.Identifier.parse(currentTrackPath);
                    net.minecraft.sounds.SoundEvent soundEvent = net.minecraft.core.registries.BuiltInRegistries.SOUND_EVENT.get(soundId)
                            .map(net.minecraft.core.Holder::value)
                            .orElse(null);
                    if (soundEvent == null) {
                        soundEvent = net.minecraft.sounds.SoundEvent.createVariableRangeEvent(soundId);
                    }
                    currentSoundInstance = new com.musicplayer.ModSoundInstance(soundEvent);
                    net.minecraft.client.Minecraft.getInstance().getSoundManager().play(currentSoundInstance);
                });
            }
        }
    }

    private void applyPerTickFade() {
        float fadeMultiplier = 1.0f;
        com.musicplayer.config.MusicPlayerConfig config = com.musicplayer.config.MusicPlayerConfig.getInstance();
        long pos = positionMs;
        long now = System.currentTimeMillis();

        if (isFadingInForUnpause) {
            long elapsed = now - fadeStartMs;
            if (elapsed >= fadeDurationMs) {
                isFadingInForUnpause = false;
            } else {
                float progress = (float) elapsed / Math.max(1, fadeDurationMs);
                progress = Math.max(0f, Math.min(1f, progress));
                fadeMultiplier = progress;
            }
        } else if (manualPauseRequested) {
            long elapsed = now - fadeStartMs;
            if (elapsed >= fadeDurationMs) {
                manualPauseRequested = false;
                paused.set(true);
                if (line != null) line.stop();
                if (isMinecraftSoundPlaying) {
                    net.minecraft.client.Minecraft.getInstance().execute(() -> {
                        if (currentSoundInstance != null) {
                            net.minecraft.client.Minecraft.getInstance().getSoundManager().stop(currentSoundInstance);
                        }
                    });
                }
                fadeMultiplier = 0.0f;
            } else {
                float progress = (float) elapsed / Math.max(1, fadeDurationMs);
                progress = Math.max(0f, Math.min(1f, progress));
                fadeMultiplier = 1.0f - progress;
            }
        } else {
            if (config.isFadeInEnabled() && pos < config.getFadeInDuration() * 1000 && !isFadingInForUnpause) {
                float progress = (float) pos / (config.getFadeInDuration() * 1000);
                progress = Math.max(0f, Math.min(1f, progress));
                fadeMultiplier = progress;
            }
            if (config.isFadeOutEnabled() && durationMs > 0 && pos > durationMs - config.getFadeOutDuration() * 1000 && !manualPauseRequested) {
                float remaining = durationMs - pos;
                float progress = 1.0f - (remaining / (config.getFadeOutDuration() * 1000));
                progress = Math.max(0f, Math.min(1f, progress));
                fadeMultiplier = 1.0f - progress;
            }
        }

        if (isDucking) {
            long duckElapsed = System.currentTimeMillis() - duckStartTimeMs;
            float duckDurationMs = config.getDuckingDuration() * 1000.0f;
            if (duckElapsed >= duckDurationMs) {
                isDucking = false;
            } else {
                float halfDuration = duckDurationMs / 2.0f;
                if (duckElapsed < halfDuration) {
                    fadeMultiplier *= 0.5f;
                } else {
                    float rampProgress = (duckElapsed - halfDuration) / halfDuration;
                    float duckMult = 0.5f + (0.5f * rampProgress);
                    fadeMultiplier *= duckMult;
                }
            }
        }

        applyVolume(fadeMultiplier);
    }

    public void triggerDucking() {
        if (com.musicplayer.config.MusicPlayerConfig.getInstance().isDuckingEnabled() && !paused.get() && playing.get()) {
            isDucking = true;
            duckStartTimeMs = System.currentTimeMillis();
        }
    }

    public void setVolume(float vol) {
        this.volume = vol;
        applyVolume(1.0f);
    }

    public float getVolume() {
        return volume;
    }

    private void applyVolume(float fadeMultiplier) {
        this.fadeVolume = fadeMultiplier;
        if (line != null && line.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl gain = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
            float masterVol = com.musicplayer.config.MusicPlayerConfig.getInstance().getMasterVolume();
            float effectiveVol = this.volume * masterVol * fadeMultiplier;
            float dB = (float) (Math.log(Math.max(0.0001, effectiveVol)) / Math.log(10.0) * 20.0);
            gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB)));
        }
    }

    public void updateMasterVolume() {
        applyVolume(1.0f);
    }

    public long getDurationMs() {
        return durationMs;
    }

    public long getPositionMs() {
        return positionMs;
    }

    public boolean isActive() {
        return playing.get();
    }

    public boolean isPaused() {
        return paused.get() || manualPauseRequested;
    }

    public float getFadeVolume() {
        return fadeVolume;
    }

    private long estimateMp3Duration(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            Bitstream bitstream = new Bitstream(fis);
            Header h = bitstream.readFrame();
            if (h != null) {
                long size = file.length();
                float kbps = h.bitrate() / 1000f;
                if (kbps > 0) return (long) ((size * 8) / kbps);
            }
        } catch (Exception ignored) {}
        return 0;
    }

    // Overload for YouTube support - but we're removing it
    public void play(String url, long seekToMs) {
        // No-op or throw error since YouTube is removed
    }

    public void playMinecraftSound(String path) {
        stop();
        stopRequested.set(false);
        playing.set(true);
        paused.set(false);
        manualPauseRequested = false;
        isFadingInForUnpause = false;
        isMinecraftSoundPlaying = true;
        currentTrackPath = path;
        
        if (onTrackStart != null) {
            onTrackStart.run();
        }

        playbackThread = new Thread(() -> {
            try {
                net.minecraft.resources.Identifier soundId = net.minecraft.resources.Identifier.parse(path);
                net.minecraft.sounds.SoundEvent soundEvent = net.minecraft.core.registries.BuiltInRegistries.SOUND_EVENT.get(soundId)
                        .map(net.minecraft.core.Holder::value)
                        .orElse(null);
                if (soundEvent == null) {
                    soundEvent = net.minecraft.sounds.SoundEvent.createVariableRangeEvent(soundId);
                }
                
                final net.minecraft.sounds.SoundEvent finalSoundEvent = soundEvent;
                durationMs = 180000; // 3 minutes simulated default
                positionMs = 0;

                // Play sound via Minecraft's sound manager on the client thread
                net.minecraft.client.Minecraft.getInstance().execute(() -> {
                    currentSoundInstance = new com.musicplayer.ModSoundInstance(finalSoundEvent);
                    net.minecraft.client.Minecraft.getInstance().getSoundManager().play(currentSoundInstance);
                });

                while (playing.get() && !stopRequested.get() && positionMs < durationMs) {
                    Thread.sleep(50);
                    if (!paused.get()) {
                        positionMs += 50;
                    }
                    applyPerTickFade();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                isMinecraftSoundPlaying = false;
                playing.set(false);
                // Stop the Minecraft sound
                net.minecraft.client.Minecraft.getInstance().execute(() -> {
                    if (currentSoundInstance != null) {
                        net.minecraft.client.Minecraft.getInstance().getSoundManager().stop(currentSoundInstance);
                        currentSoundInstance = null;
                    }
                });
                if (onFinished != null && !stopRequested.get()) {
                    onFinished.run();
                }
            }
        });
        playbackThread.setName("MinecraftSoundPlaybackThread");
        playbackThread.start();
    }
}
