package com.musicplayer;

import com.musicplayer.config.MusicPlayerConfig;
import com.musicplayer.config.MusicPlayerConfig.PlaybackMode;

import java.io.File;
import java.util.*;

/**
 * High-level music playback manager (singleton).
 * Orchestrates the playlist, playback modes, and delegates to AudioEngine.
 */
public class MusicPlayerManager {

    private static final MusicPlayerManager INSTANCE = new MusicPlayerManager();

    private final AudioEngine engine = new AudioEngine();
    private final MusicPlayerConfig config = MusicPlayerConfig.getInstance();

    private final List<SongInfo> playlist = new ArrayList<>();
    private final List<Integer> shuffleOrder = new ArrayList<>();
    private int currentIndex = -1;
    private int shuffleIndex = -1;
    private boolean loaded = false;
    private Playlist currentCustomPlaylist = null;

    private MusicPlayerManager() {
        engine.setVolume(config.getVolume());
        engine.setOnFinished(this::onTrackFinished);
        engine.setOnTrackStart(() -> {
            SongInfo current = getCurrentSong();
            if (current != null) {
                com.musicplayer.notification.NotificationManager.showNowPlaying(current);
            }
        });
    }

    public static MusicPlayerManager getInstance() {
        return INSTANCE;
    }

    /**
     * Scans the configured music folder and populates the library.
     */
    public void reloadLibraryFromDisk() {
        playlist.clear();
        shuffleOrder.clear();
        currentIndex = -1;
        shuffleIndex = -1;

        String folderPath = config.getMusicFolderPath();
        if (folderPath == null || folderPath.isEmpty()) {
            loaded = true;
            return;
        }

        File folder = new File(folderPath);
        if (!folder.exists() || !folder.isDirectory()) {
            loaded = true;
            return;
        }

        File[] files = folder.listFiles((dir, name) -> {
            String lower = name.toLowerCase();
            return lower.endsWith(".mp3") || lower.endsWith(".wav");
        });

        if (files != null) {
            Arrays.sort(files, Comparator.comparing(f -> f.getName().toLowerCase()));
            for (File file : files) {
                playlist.add(SongInfo.fromFile(file));
            }
        }

        regenerateShuffleOrder();

        // Try to restore last played song
        String lastSong = config.getLastPlayedSong();
        if (lastSong != null && !lastSong.isEmpty()) {
            for (int i = 0; i < playlist.size(); i++) {
                if (playlist.get(i).getTitle().equals(lastSong)) {
                    currentIndex = i;
                    break;
                }
            }
        }

        loaded = true;
    }

    /**
     * Loads a specific custom playlist.
     */
    public void loadCustomPlaylist(Playlist playlistObj) {
        playlist.clear();
        shuffleOrder.clear();
        currentIndex = -1;
        shuffleIndex = -1;
        currentCustomPlaylist = playlistObj;

        playlist.addAll(playlistObj.getSongs());

        regenerateShuffleOrder();
        loaded = true;
    }

    /**
     * Switches back to the main music folder library.
     */
    public void switchToMainLibrary() {
        currentCustomPlaylist = null;
        reloadLibraryFromDisk();
    }

    public Playlist getCurrentCustomPlaylist() {
        return currentCustomPlaylist;
    }

    public boolean isUsingCustomPlaylist() {
        return currentCustomPlaylist != null;
    }

    public void setMusicFolder(String path) {
        config.setMusicFolderPath(path);
        reloadLibraryFromDisk();
    }

    // ---- Playback controls ----

    public void playSong(int index) {
        if (index < 0 || index >= playlist.size()) return;
        currentIndex = index;
        SongInfo song = playlist.get(index);
        config.setLastPlayedSong(song.getTitle());
        
        ListeningStatisticsManager.getInstance().startTrack(song);
        
        if (song.getSource() == SongInfo.SourceType.LOCAL) {
            engine.play(new File(song.getPath()), 0);
        } else {
            engine.playMinecraftSound(song.getPath());
        }
    }

    public void togglePlayPause() {
        if (engine.isActive()) {
            boolean wasPaused = engine.isPaused();
            engine.togglePause();
            if (wasPaused) {
                ListeningStatisticsManager.getInstance().resumeTrack(getCurrentSong());
            } else {
                ListeningStatisticsManager.getInstance().pauseTrack();
            }
        } else if (!playlist.isEmpty()) {
            if (currentIndex < 0) currentIndex = 0;
            playSong(currentIndex);
        }
    }

    public void stop() {
        engine.stop();
        ListeningStatisticsManager.getInstance().stopTrack();
    }

    public void nextTrack() {
        if (playlist.isEmpty()) return;

        PlaybackMode mode = config.getPlaybackMode();
        switch (mode) {
            case SHUFFLE:
                shuffleIndex++;
                if (shuffleIndex >= shuffleOrder.size()) {
                    regenerateShuffleOrder();
                    shuffleIndex = 0;
                }
                playSong(shuffleOrder.get(shuffleIndex));
                break;
            case REPEAT_ONE:
                playSong(currentIndex >= 0 ? currentIndex : 0);
                break;
            case REPEAT_ALL:
                currentIndex = (currentIndex + 1) % playlist.size();
                playSong(currentIndex);
                break;
            default: // SEQUENTIAL
                if (currentIndex + 1 < playlist.size()) {
                    playSong(currentIndex + 1);
                } else {
                    stop();
                }
                break;
        }
    }

    public void previousTrack() {
        if (playlist.isEmpty()) return;

        if (engine.getPositionMs() > 3000 && currentIndex >= 0) {
            playSong(currentIndex);
            return;
        }

        PlaybackMode mode = config.getPlaybackMode();
        if (mode == PlaybackMode.SHUFFLE) {
            shuffleIndex--;
            if (shuffleIndex < 0) {
                regenerateShuffleOrder();
                shuffleIndex = shuffleOrder.size() - 1;
            }
            playSong(shuffleOrder.get(shuffleIndex));
        } else {
            if (currentIndex > 0) {
                playSong(currentIndex - 1);
            } else if (mode == PlaybackMode.REPEAT_ALL) {
                playSong(playlist.size() - 1);
            } else {
                playSong(0);
            }
        }
    }

    public void seek(float percent) {
        if (currentIndex < 0 || currentIndex >= playlist.size()) return;
        long targetMs = (long) (engine.getDurationMs() * Math.max(0, Math.min(1, percent)));
        SongInfo song = playlist.get(currentIndex);
        if (song.getSource() == SongInfo.SourceType.LOCAL) {
            engine.play(new File(song.getPath()), targetMs);
        }
    }

    public void adjustVolume(float delta) {
        float newVol = Math.max(0f, Math.min(1f, engine.getVolume() + delta));
        engine.setVolume(newVol);
        config.setVolume(newVol);
    }

    public void setVolume(float vol) {
        engine.setVolume(vol);
        config.setVolume(vol);
    }

    public void cyclePlaybackMode() {
        PlaybackMode current = config.getPlaybackMode();
        PlaybackMode next = switch (current) {
            case SEQUENTIAL -> PlaybackMode.SHUFFLE;
            case SHUFFLE -> PlaybackMode.REPEAT_ALL;
            case REPEAT_ALL -> PlaybackMode.REPEAT_ONE;
            case REPEAT_ONE -> PlaybackMode.SEQUENTIAL;
        };
        config.setPlaybackMode(next);
        if (next == PlaybackMode.SHUFFLE) {
            regenerateShuffleOrder();
            shuffleIndex = -1;
        }
    }

    public void setPlaybackMode(PlaybackMode mode) {
        config.setPlaybackMode(mode);
        if (mode == PlaybackMode.SHUFFLE) {
            regenerateShuffleOrder();
            shuffleIndex = -1;
        }
    }

    public void toggleShuffle() {
        if (config.getPlaybackMode() == PlaybackMode.SHUFFLE) {
            config.setPlaybackMode(PlaybackMode.SEQUENTIAL);
        } else {
            config.setPlaybackMode(PlaybackMode.SHUFFLE);
            regenerateShuffleOrder();
            shuffleIndex = -1;
        }
    }

    public void toggleRepeat() {
        if (config.getPlaybackMode() == PlaybackMode.REPEAT_ALL) {
            config.setPlaybackMode(PlaybackMode.SEQUENTIAL);
        } else {
            config.setPlaybackMode(PlaybackMode.REPEAT_ALL);
        }
    }

    // ---- Getters ----

    public List<SongInfo> getPlaylist() {
        return Collections.unmodifiableList(playlist);
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public SongInfo getCurrentSong() {
        if (currentIndex >= 0 && currentIndex < playlist.size()) {
            return playlist.get(currentIndex);
        }
        return null;
    }

    public AudioEngine getEngine() {
        return engine;
    }

    public MusicPlayerConfig getConfig() {
        return config;
    }

    public boolean isLoaded() {
        return loaded;
    }

    public float getProgress() {
        long duration = engine.getDurationMs();
        if (duration <= 0) return 0f;
        return Math.min(1f, (float) engine.getPositionMs() / duration);
    }

    // ---- Private helpers ----

    private void regenerateShuffleOrder() {
        shuffleOrder.clear();
        for (int i = 0; i < playlist.size(); i++) {
            shuffleOrder.add(i);
        }
        Collections.shuffle(shuffleOrder);
    }

    private void onTrackFinished() {
        nextTrack();
    }

    public static String formatTime(long ms) {
        if (ms < 0) ms = 0;
        long totalSeconds = ms / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    public static long estimateDuration(File file) {
        return 0; // Handled by AudioEngine/LavaPlayer
    }
}
