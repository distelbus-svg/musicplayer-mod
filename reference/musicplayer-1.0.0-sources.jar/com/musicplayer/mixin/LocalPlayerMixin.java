package com.musicplayer.mixin;

import com.musicplayer.MusicPlayerManager;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public class LocalPlayerMixin {
    @Inject(method = "handleEntityEvent", at = @At("HEAD"))
    private void onHandleEntityEvent(byte id, CallbackInfo ci) {
        if (id == 2) {
            if (MusicPlayerManager.getInstance().getEngine() != null) {
                MusicPlayerManager.getInstance().getEngine().triggerDucking();
            }
        }
    }
}

