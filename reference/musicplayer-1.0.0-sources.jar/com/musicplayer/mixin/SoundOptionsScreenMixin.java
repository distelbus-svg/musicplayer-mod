package com.musicplayer.mixin;

import com.musicplayer.widget.MusicPlayerSliderWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.SoundOptionsScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundOptionsScreen.class)
public class SoundOptionsScreenMixin extends Screen {

    protected SoundOptionsScreenMixin(Component component) {
        super(component);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        int sliderWidth = 150;
        int x = this.width / 2 - sliderWidth / 2;
        int y = this.height / 6 + 144; // Bottom of options
        
        this.addRenderableWidget(new MusicPlayerSliderWidget(x, y, sliderWidth, 20));
    }
}
