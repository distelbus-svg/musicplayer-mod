package com.musicplayer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.resources.Identifier;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

/**
 * Music Player Mod — Client-side Fabric mod entry point.
 * Registers keybindings and initializes the music player manager.
 *
 * Keybindings (all rebindable in Controls menu):
 *   M          — Open the music player GUI
 *   Right Arrow — Next track
 *   Left Arrow  — Previous track
 *   P          — Play / Pause
 *   Up Arrow   — Volume up (+5%)
 *   Down Arrow — Volume down (-5%)
 */
public class MusicPlayerMod implements ClientModInitializer {

    public static final String MOD_ID = "musicplayer";
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(MOD_ID, "main")
    );

    // Keybindings
    private static KeyMapping openGuiKey;
    private static KeyMapping playPauseKey;
    private static KeyMapping nextTrackKey;
    private static KeyMapping prevTrackKey;
    private static KeyMapping volumeUpKey;
    private static KeyMapping volumeDownKey;

    private static boolean wasGamePaused = false;
    private static boolean pausedDueToGamePause = false;
    private static boolean wasWindowFocused = true;
    private static boolean pausedDueToFocusLoss = false;

    @Override
    public void onInitializeClient() {
        System.out.println("[MusicPlayer] Initializing Music Player Mod...");
        
        com.musicplayer.notification.NotificationManager.init();

        // Register keybindings
        openGuiKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.musicplayer.open_gui",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                CATEGORY
        ));

        playPauseKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.musicplayer.play_pause",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                CATEGORY
        ));

        nextTrackKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.musicplayer.next_track",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT,
                CATEGORY
        ));

        prevTrackKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.musicplayer.previous_track",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT,
                CATEGORY
        ));

        volumeUpKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.musicplayer.volume_up",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_UP,
                CATEGORY
        ));

        volumeDownKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.musicplayer.volume_down",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_DOWN,
                CATEGORY
        ));

        // Initialize manager (loads config + playlist)
        MusicPlayerManager manager = MusicPlayerManager.getInstance();
        manager.reloadLibraryFromDisk();

        // Register tick event to handle keybinds
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Only process keybinds when no screen is open (in-game)
            // Exception: open GUI key always works
            if (openGuiKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new MusicPlayerScreen());
                } else if (client.screen instanceof MusicPlayerScreen) {
                    client.setScreen(null); // Toggle off
                }
            }

            // These controls work even without the GUI open
            if (client.screen == null) {
                while (playPauseKey.consumeClick()) {
                    manager.togglePlayPause();
                }
                while (nextTrackKey.consumeClick()) {
                    manager.nextTrack();
                }
                while (prevTrackKey.consumeClick()) {
                    manager.previousTrack();
                }
                while (volumeUpKey.consumeClick()) {
                    manager.adjustVolume(0.05f);
                }
                while (volumeDownKey.consumeClick()) {
                    manager.adjustVolume(-0.05f);
                }
            }
            // Singleplayer game pause handling
            com.musicplayer.config.MusicPlayerConfig config = com.musicplayer.config.MusicPlayerConfig.getInstance();
            boolean isPausedNow = client.isPaused();
            if (config.isPauseOnGamePause()) {
                if (isPausedNow && !wasGamePaused) {
                    if (manager.getEngine() != null && !manager.getEngine().isPaused() && manager.getEngine().isActive()) {
                        manager.togglePlayPause();
                        pausedDueToGamePause = true;
                    }
                } else if (!isPausedNow && wasGamePaused) {
                    if (pausedDueToGamePause) {
                        if (manager.getEngine() != null && manager.getEngine().isPaused()) {
                            manager.togglePlayPause();
                        }
                        pausedDueToGamePause = false;
                    }
                }
            } else {
                pausedDueToGamePause = false;
            }
            wasGamePaused = isPausedNow;

            // Window focus loss handling
            boolean isFocusedNow = client.isWindowActive();
            if (config.isPauseOnLostFocus()) {
                if (!isFocusedNow && wasWindowFocused) {
                    if (manager.getEngine() != null && !manager.getEngine().isPaused() && manager.getEngine().isActive()) {
                        manager.togglePlayPause();
                        pausedDueToFocusLoss = true;
                    }
                } else if (isFocusedNow && !wasWindowFocused) {
                    if (pausedDueToFocusLoss) {
                        if (manager.getEngine() != null && manager.getEngine().isPaused()) {
                            manager.togglePlayPause();
                        }
                        pausedDueToFocusLoss = false;
                    }
                }
            } else {
                pausedDueToFocusLoss = false;
            }
            wasWindowFocused = isFocusedNow;
        });

        System.out.println("[MusicPlayer] Music Player Mod initialized!");
    }
}
