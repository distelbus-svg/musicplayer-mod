package com.musicplayer.notification;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import com.musicplayer.SongInfo;
import com.musicplayer.MusicPlayerManager;
import com.musicplayer.config.MusicPlayerConfig;

public class NotificationManager {

    private static String systemMessage = null;
    private static long systemMessageTime = 0;
    
    private static SongInfo nowPlayingSong = null;
    private static long nowPlayingTime = 0;

    public static void init() {
    }

    public static void showSystem(String message) {
        systemMessage = message;
        systemMessageTime = System.currentTimeMillis();
    }

    public static void showNowPlaying(SongInfo song) {
        nowPlayingSong = song;
        nowPlayingTime = System.currentTimeMillis();
    }

    public static void renderNotifications(GuiGraphicsExtractor graphics) {
        long currentTime = System.currentTimeMillis();
        Minecraft mc = Minecraft.getInstance();
        int screenWidth = mc.getWindow().getGuiScaledWidth();
        MusicPlayerConfig.NowPlayingStyle style = MusicPlayerManager.getInstance().getConfig().getNowPlayingStyle();
        
        // System Notification
        if (systemMessage != null) {
            long elapsed = currentTime - systemMessageTime;
            if (elapsed > 5000) {
                systemMessage = null;
            } else {
                int width = 160;
                int height = 32;
                int x = screenWidth - width - 10;
                if (elapsed < 500) x += (int)((1.0 - (elapsed / 500.0)) * width);
                if (elapsed > 4500) x += (int)(((elapsed - 4500) / 500.0) * width);
                
                graphics.fill(x, 10, x + width, 10 + height, 0xDD000000);
                graphics.text(mc.font, "Music Player", x + 8, 14, 0xFF55FF55, false);
                graphics.text(mc.font, systemMessage, x + 8, 28, 0xFFFFFFFF, false);
            }
        }

        // Now Playing Notification
        if (nowPlayingSong != null) {
            long elapsed = currentTime - nowPlayingTime;
            if (elapsed > 5000) {
                nowPlayingSong = null;
            } else {
                if (style == MusicPlayerConfig.NowPlayingStyle.HOTBAR_TEXT) {
                    long pos = MusicPlayerManager.getInstance().getEngine().getPositionMs();
                    long dur = MusicPlayerManager.getInstance().getEngine().getDurationMs();
                    String timeStr = MusicPlayerManager.formatTime(pos) + " / " + MusicPlayerManager.formatTime(dur);
                    mc.gui.setOverlayMessage(Component.literal(nowPlayingSong.getTitle() + " - " + timeStr), false);
                } else {
                    int width = 160;
                    int height = 32;
                    int yOffset = (systemMessage != null) ? 50 : 10;
                    int x = screenWidth - width - 10;
                    if (elapsed < 500) x += (int)((1.0 - (elapsed / 500.0)) * width);
                    if (elapsed > 4500) x += (int)(((elapsed - 4500) / 500.0) * width);
                    
                    graphics.fill(x, yOffset, x + width, yOffset + height, 0xDD000000);
                    graphics.text(mc.font, "\u25CE", x + 8, yOffset + 14, 0xFF55FFFF, false); // Fake disc icon
                    
                    // Truncate title if needed
                    String title = nowPlayingSong.getTitle();
                    if (mc.font.width(title) > 120) {
                        title = mc.font.plainSubstrByWidth(title, 115) + "...";
                    }
                    graphics.text(mc.font, title, x + 30, yOffset + 8, 0xFFFFFFFF, false);
                    
                    long pos = MusicPlayerManager.getInstance().getEngine().getPositionMs();
                    long dur = MusicPlayerManager.getInstance().getEngine().getDurationMs();
                    String timeStr = MusicPlayerManager.formatTime(pos) + " / " + MusicPlayerManager.formatTime(dur);
                    
                    graphics.text(mc.font, "\u25B6 " + timeStr, x + 30, yOffset + 20, 0xFFAAAAAA, false);
                }
            }
        }
    }
}
