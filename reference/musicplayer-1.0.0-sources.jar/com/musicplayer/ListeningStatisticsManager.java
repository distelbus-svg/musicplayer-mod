package com.musicplayer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class ListeningStatisticsManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path STATS_FILE = FabricLoader.getInstance().getConfigDir().resolve("musicplayer").resolve("stats.json");
    private static ListeningStatisticsManager instance;

    private long totalListeningTimeSeconds = 0;
    private final Map<String, Integer> playCounts = new HashMap<>();
    private final Map<String, Long> listeningTimes = new HashMap<>();

    // Temporary session state
    private transient long sessionListeningTimeSeconds = 0;
    private final transient Map<String, Integer> sessionPlayCounts = new HashMap<>();
    private final transient Map<String, Long> sessionListeningTimes = new HashMap<>();

    private transient long currentTrackStartTime = -1;
    private transient String currentTrackPath = null;
    private transient String currentTrackTitle = null;

    private ListeningStatisticsManager() {
        load();
    }

    public static synchronized ListeningStatisticsManager getInstance() {
        if (instance == null) {
            instance = new ListeningStatisticsManager();
        }
        return instance;
    }

    public synchronized void load() {
        if (!Files.exists(STATS_FILE)) {
            return;
        }
        try (Reader reader = Files.newBufferedReader(STATS_FILE)) {
            ListeningStatisticsManager data = GSON.fromJson(reader, ListeningStatisticsManager.class);
            if (data != null) {
                this.totalListeningTimeSeconds = data.totalListeningTimeSeconds;
                this.playCounts.clear();
                this.playCounts.putAll(data.playCounts);
                this.listeningTimes.clear();
                if (data.listeningTimes != null) {
                    this.listeningTimes.putAll(data.listeningTimes);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void save() {
        try {
            Files.createDirectories(STATS_FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(STATS_FILE)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void startTrack(SongInfo song) {
        // If there was a track playing, accumulate its time first
        stopTrack();
        
        currentTrackPath = song.getPath();
        currentTrackTitle = song.getTitle();
        currentTrackStartTime = System.currentTimeMillis();
        
        // Increment play count (all-time)
        playCounts.put(song.getTitle(), playCounts.getOrDefault(song.getTitle(), 0) + 1);
        // Increment play count (session)
        sessionPlayCounts.put(song.getTitle(), sessionPlayCounts.getOrDefault(song.getTitle(), 0) + 1);
        save();
    }

    public synchronized void stopTrack() {
        if (currentTrackStartTime != -1 && currentTrackTitle != null) {
            long elapsedMs = System.currentTimeMillis() - currentTrackStartTime;
            long elapsedSecs = elapsedMs / 1000;
            if (elapsedSecs > 0) {
                totalListeningTimeSeconds += elapsedSecs;
                sessionListeningTimeSeconds += elapsedSecs;
                
                // Accumulate per song listening time (all-time)
                listeningTimes.put(currentTrackTitle, listeningTimes.getOrDefault(currentTrackTitle, 0L) + elapsedSecs);
                // Accumulate per song listening time (session)
                sessionListeningTimes.put(currentTrackTitle, sessionListeningTimes.getOrDefault(currentTrackTitle, 0L) + elapsedSecs);
            }
            currentTrackStartTime = -1;
            currentTrackPath = null;
            currentTrackTitle = null;
            save();
        }
    }

    public synchronized void pauseTrack() {
        stopTrack();
    }

    public synchronized void resumeTrack(SongInfo song) {
        currentTrackPath = song.getPath();
        currentTrackTitle = song.getTitle();
        currentTrackStartTime = System.currentTimeMillis();
    }

    public synchronized long getTotalListeningTimeSeconds() {
        return totalListeningTimeSeconds;
    }

    public synchronized Map<String, Integer> getPlayCounts() {
        return new HashMap<>(playCounts);
    }

    public synchronized Map<String, Long> getListeningTimes() {
        return new HashMap<>(listeningTimes);
    }

    // Session stats getters
    public synchronized long getSessionListeningTimeSeconds() {
        return sessionListeningTimeSeconds;
    }

    public synchronized Map<String, Integer> getSessionPlayCounts() {
        return new HashMap<>(sessionPlayCounts);
    }

    public synchronized Map<String, Long> getSessionListeningTimes() {
        return new HashMap<>(sessionListeningTimes);
    }
}
