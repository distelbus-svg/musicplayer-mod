package com.musicplayer;

import com.musicplayer.widget.SongListWidget;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PlaylistEditScreen extends ScaledScreen {
    private final Screen parent;
    private final Playlist playlist;
    
    private SongListWidget sourceList;
    private SongListWidget playlistList;
    
    private int activeTab = 0; // 0: Folder, 1: Music Discs, 2: All
    private boolean showingSource = false;

    private boolean isRenaming = false;
    private EditBox renameInput;
    private Button renameConfirmBtn;
    private Button renameCancelBtn;
    private Button startRenameBtn;

    public PlaylistEditScreen(Screen parent, Playlist playlist) {
        super(Component.literal("Editing: " + playlist.getName()));
        this.parent = parent;
        this.playlist = playlist;
    }

    @Override
    protected void initScaled() {
        int panelWidth = 360;
        int panelHeight = 260;
        int panelLeft = (this.width - panelWidth) / 2;
        int panelTop = (this.height - panelHeight) / 2;

        int listWidth = panelWidth - 40;
        int listHeight = panelHeight - 110;
        int listX = panelLeft + 20;
        int listY = panelTop + 50;

        // ---- Current Playlist View ----
        playlistList = new SongListWidget(this.minecraft, listWidth, listHeight, listY, 16);
        playlistList.setX(listX);
        playlistList.setY(listY);
        playlistList.setOnSelect((song, index) -> {
            // Do nothing - quick-remove is disabled for stability
        });
        updatePlaylistView();
        addRenderableWidget(playlistList);

        // ---- Source View ----
        sourceList = new SongListWidget(this.minecraft, listWidth, listHeight, listY, 16);
        sourceList.setX(listX);
        sourceList.setY(listY);
        sourceList.setCheckboxStateProvider(song -> {
            for (SongInfo s : playlist.getSongs()) {
                if (s.getPath().equals(song.getPath())) return true;
            }
            return false;
        });
        sourceList.setOnSelect((song, index) -> {
            boolean inPlaylist = false;
            for (SongInfo s : playlist.getSongs()) {
                if (s.getPath().equals(song.getPath())) {
                    inPlaylist = true;
                    break;
                }
            }
            if (inPlaylist) {
                // Remove it
                playlist.getSongs().removeIf(s -> s.getPath().equals(song.getPath()));
            } else {
                playlist.addSong(song);
            }
            // Just visually update the checkbox, no need to refresh entire list
        });
        sourceList.visible = false;
        addRenderableWidget(sourceList);

        // ---- Source Tabs ----
        int tabY = panelTop + 25;
        addRenderableWidget(Button.builder(Component.literal("Folder"), b -> switchTab(0))
                .bounds(panelLeft + 20, tabY, 60, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Music Discs"), b -> switchTab(1))
                .bounds(panelLeft + 85, tabY, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("All"), b -> switchTab(2))
                .bounds(panelLeft + 170, tabY, 50, 20).build());

        // Toggle button (Edit Songs / Show Playlist)
        addRenderableWidget(Button.builder(Component.literal("Edit Songs"), button -> {
            showingSource = !showingSource;
            if (showingSource) {
                refreshSourceList();
            } else {
                updatePlaylistView();
            }
            updateTabVisibility();
            button.setMessage(Component.literal(showingSource ? "Show Playlist" : "Edit Songs"));
        }).bounds(panelLeft + 20, panelTop + panelHeight - 30, 100, 20).build());

        // Done button
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> {
            PlaylistManager.getInstance().savePlaylist(playlist);
            this.minecraft.setScreen(parent);
        }).bounds(panelLeft + panelWidth - 80, panelTop + panelHeight - 30, 60, 20).build());

        // Rename logic
        renameInput = new EditBox(this.font, panelLeft + panelWidth / 2 - 70, panelTop + 5, 100, 16, Component.empty());
        renameInput.setMaxLength(64);
        renameInput.visible = false;
        addRenderableWidget(renameInput);

        renameConfirmBtn = Button.builder(Component.literal("\u2713"), b -> {
            String newName = renameInput.getValue().trim();
            if (!newName.isEmpty() && !newName.equals(playlist.getName())) {
                PlaylistManager.getInstance().rename(playlist, newName);
            }
            isRenaming = false;
            updateRenameUIVisibility();
        }).bounds(panelLeft + panelWidth / 2 + 35, panelTop + 3, 20, 20).build();
        renameConfirmBtn.visible = false;
        addRenderableWidget(renameConfirmBtn);

        renameCancelBtn = Button.builder(Component.literal("X"), b -> {
            isRenaming = false;
            updateRenameUIVisibility();
        }).bounds(panelLeft + panelWidth / 2 + 57, panelTop + 3, 20, 20).build();
        renameCancelBtn.visible = false;
        addRenderableWidget(renameCancelBtn);

        startRenameBtn = Button.builder(Component.literal("\u270E"), b -> {
            isRenaming = true;
            renameInput.setValue(playlist.getName());
            updateRenameUIVisibility();
        }).bounds(panelLeft + panelWidth - 30, panelTop + 3, 20, 20).build();
        addRenderableWidget(startRenameBtn);
    }

    private void updateRenameUIVisibility() {
        renameInput.visible = isRenaming;
        renameConfirmBtn.visible = isRenaming;
        renameCancelBtn.visible = isRenaming;
        startRenameBtn.visible = !isRenaming;
    }

    private void switchTab(int tab) {
        this.activeTab = tab;
        this.showingSource = true;
        updateTabVisibility();
        refreshSourceList();
    }

    private void updateTabVisibility() {
        sourceList.visible = showingSource;
        playlistList.visible = !showingSource;
    }

    private void refreshSourceList() {
        List<SongInfo> songs = new ArrayList<>();

        // Helper to load local folder
        Runnable loadFolder = () -> {
            String folderPath = MusicPlayerManager.getInstance().getConfig().getMusicFolderPath();
            File folder = new File(folderPath);
            if (folder.exists() && folder.isDirectory()) {
                File[] files = folder.listFiles((dir, name) -> name.endsWith(".mp3") || name.endsWith(".wav"));
                if (files != null) {
                    for (File f : files) songs.add(SongInfo.fromFile(f));
                }
            }
        };

        // Helper to load discs (from the default playlist we will create later)
        // Or we just scan all playlists for songs that are DISC type
        Runnable loadDiscs = () -> {
            for (Playlist p : PlaylistManager.getInstance().getPlaylists()) {
                for (SongInfo s : p.getSongs()) {
                    if (s.getSource() == SongInfo.SourceType.DISC && !songs.contains(s)) {
                        songs.add(s);
                    }
                }
            }
        };

        if (activeTab == 0) {
            loadFolder.run();
        } else if (activeTab == 1) {
            loadDiscs.run();
        } else if (activeTab == 2) {
            loadFolder.run();
            loadDiscs.run();
            // Also MINECRAFT_MUSIC could be added here
            for (Playlist p : PlaylistManager.getInstance().getPlaylists()) {
                for (SongInfo s : p.getSongs()) {
                    if (s.getSource() == SongInfo.SourceType.MINECRAFT_MUSIC && !songs.contains(s)) {
                        songs.add(s);
                    }
                }
            }
        }
        
        sourceList.setSongs(songs);
    }

    private void updatePlaylistView() {
        playlistList.setSongs(playlist.getSongs());
    }

    @Override
    public void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        this.extractMenuBackground(graphics);
        int panelWidth = 360;
        int panelHeight = 260;
        int panelLeft = (this.width - panelWidth) / 2;
        int panelTop = (this.height - panelHeight) / 2;

        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, 0xDD222222);

        if (!isRenaming) {
            String title = "Playlist: " + playlist.getName();
            graphics.centeredText(this.font, title, panelLeft + panelWidth / 2, panelTop + 8, 0xFFFFFFFF);
        }

        super.renderScaled(graphics, mouseX, mouseY, partialTick);
    }
}
