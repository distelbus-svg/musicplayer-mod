package com.musicplayer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.MouseButtonEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ListeningStatisticsScreen extends ScaledScreen {
    private final Screen parent;
    private StatsListWidget listWidget;

    private boolean isHoursUnit = true; // h vs min
    private boolean isSessionScope = false; // session vs all-time
    private int sortBy = 2; // 0: Alphabetical, 1: Plays, 2: Listening time

    private Button topUnitBtn;
    private Button topScopeBtn;
    private Button bottomUnitBtn;
    private Button bottomScopeBtn;
    private Button sortBtn;

    public ListeningStatisticsScreen(Screen parent) {
        super(Component.literal("Listening Statistics"));
        this.parent = parent;
    }

    @Override
    protected void initScaled() {
        int panelWidth = 380;
        int panelHeight = 260;
        int panelLeft = (this.width - panelWidth) / 2;
        int panelTop = (this.height - panelHeight) / 2;

        int listWidth = panelWidth - 24;
        int listHeight = panelHeight - 79 - 36;
        int listX = panelLeft + 12;
        int listY = panelTop + 81;

        listWidget = new StatsListWidget(this.minecraft, listWidth, listHeight, listY, 18);
        listWidget.setX(listX);
        listWidget.setY(listY);
        addRenderableWidget(listWidget);

        // ---- Create Toggles ----
        topUnitBtn = Button.builder(Component.literal("h"), b -> toggleUnit())
                .bounds(panelLeft + 200, panelTop + 20, 40, 16).build();
        addRenderableWidget(topUnitBtn);

        topScopeBtn = Button.builder(Component.literal("All-Time"), b -> toggleScope())
                .bounds(panelLeft + 245, panelTop + 20, 120, 16).build();
        addRenderableWidget(topScopeBtn);

        bottomScopeBtn = Button.builder(Component.literal("All-Time"), b -> toggleScope())
                .bounds(panelLeft + 130, panelTop + 43, 75, 16).build();
        addRenderableWidget(bottomScopeBtn);

        bottomUnitBtn = Button.builder(Component.literal("h"), b -> toggleUnit())
                .bounds(panelLeft + 210, panelTop + 43, 30, 16).build();
        addRenderableWidget(bottomUnitBtn);

        sortBtn = Button.builder(Component.literal("Sort: Time"), b -> toggleSort())
                .bounds(panelLeft + 245, panelTop + 43, 120, 16).build();
        addRenderableWidget(sortBtn);

        // Done button
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> {
            this.onClose();
        }).bounds(panelLeft + panelWidth / 2 - 40, panelTop + panelHeight - 24, 80, 18).build());

        updateButtonLabels();
        refreshStats();
    }

    private void toggleUnit() {
        isHoursUnit = !isHoursUnit;
        updateButtonLabels();
        refreshStats();
    }

    private void toggleScope() {
        isSessionScope = !isSessionScope;
        updateButtonLabels();
        refreshStats();
    }

    private void toggleSort() {
        sortBy = (sortBy + 1) % 3;
        updateButtonLabels();
        refreshStats();
    }

    private void updateButtonLabels() {
        String scopeText = isSessionScope ? "Session" : "All-Time";
        String unitText = isHoursUnit ? "h" : "min";
        String sortText = switch (sortBy) {
            case 0 -> "Sort: A-Z";
            case 1 -> "Sort: Plays";
            default -> "Sort: Time";
        };

        if (topUnitBtn != null) topUnitBtn.setMessage(Component.literal(unitText));
        if (bottomUnitBtn != null) bottomUnitBtn.setMessage(Component.literal(unitText));
        if (topScopeBtn != null) topScopeBtn.setMessage(Component.literal(scopeText));
        if (bottomScopeBtn != null) bottomScopeBtn.setMessage(Component.literal(scopeText));
        if (sortBtn != null) sortBtn.setMessage(Component.literal(sortText));
    }

    private void refreshStats() {
        if (listWidget == null) return;
        listWidget.clear();

        ListeningStatisticsManager stats = ListeningStatisticsManager.getInstance();
        Map<String, Integer> playCounts = isSessionScope ? stats.getSessionPlayCounts() : stats.getPlayCounts();
        Map<String, Long> listeningTimes = isSessionScope ? stats.getSessionListeningTimes() : stats.getListeningTimes();

        // Get union of all song titles
        List<SongStat> songStats = new ArrayList<>();
        for (String title : playCounts.keySet()) {
            int plays = playCounts.getOrDefault(title, 0);
            long time = listeningTimes.getOrDefault(title, 0L);
            if (plays > 0 || time > 0) {
                songStats.add(new SongStat(title, plays, time));
            }
        }
        for (String title : listeningTimes.keySet()) {
            if (!playCounts.containsKey(title)) {
                int plays = playCounts.getOrDefault(title, 0);
                long time = listeningTimes.getOrDefault(title, 0L);
                if (plays > 0 || time > 0) {
                    songStats.add(new SongStat(title, plays, time));
                }
            }
        }

        // Sort based on sortBy
        if (sortBy == 0) { // Alphabetical
            songStats.sort((a, b) -> a.title.compareToIgnoreCase(b.title));
        } else if (sortBy == 1) { // Plays
            songStats.sort((a, b) -> Integer.compare(b.plays, a.plays));
        } else { // Listening time
            songStats.sort((a, b) -> Long.compare(b.time, a.time));
        }

        // Add to list widget
        for (SongStat stat : songStats) {
            String timeStr;
            if (isHoursUnit) {
                timeStr = String.format("%d:%02d h", stat.time / 3600, (stat.time % 3600) / 60);
            } else {
                timeStr = String.format("%d min", stat.time / 60);
            }
            listWidget.addEntry(new StatsEntry(stat.title, timeStr, stat.plays));
        }
    }

    @Override
    public void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        this.extractMenuBackground(graphics);
        int panelWidth = 380;
        int panelHeight = 260;
        int panelLeft = (this.width - panelWidth) / 2;
        int panelTop = (this.height - panelHeight) / 2;

        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, 0xDD222222);

        // Title
        graphics.centeredText(this.font, this.title, panelLeft + panelWidth / 2, panelTop + 8, 0xFFFFFFFF);

        // Listening Time: 10:30 h
        ListeningStatisticsManager stats = ListeningStatisticsManager.getInstance();
        long totalSecs = isSessionScope ? stats.getSessionListeningTimeSeconds() : stats.getTotalListeningTimeSeconds();
        String timeLabel;
        if (isHoursUnit) {
            timeLabel = String.format("Listening Time: %d:%02d h", totalSecs / 3600, (totalSecs % 3600) / 60);
        } else {
            timeLabel = String.format("Listening Time: %d min", totalSecs / 60);
        }
        graphics.text(this.font, timeLabel, panelLeft + 12, panelTop + 24, 0xFFFFFFFF, true);

        // Divider
        graphics.fill(panelLeft + 8, panelTop + 40, panelLeft + panelWidth - 8, panelTop + 41, 0xFF555555);

        // Songs title
        graphics.text(this.font, "Songs", panelLeft + 12, panelTop + 47, 0xFFFFFFFF, true);

        // Table Header
        graphics.text(this.font, "Song Title", panelLeft + 18, panelTop + 67, 0xFFAAAAAA, true);
        graphics.text(this.font, "Listening Time", panelLeft + 212, panelTop + 67, 0xFFAAAAAA, true);
        graphics.text(this.font, "Times played", panelLeft + 302, panelTop + 67, 0xFFAAAAAA, true);

        // Faint Header Divider
        graphics.fill(panelLeft + 8, panelTop + 78, panelLeft + panelWidth - 8, panelTop + 79, 0xFF3C3C3C);

        super.renderScaled(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // SongStat class helper
    private static class SongStat {
        public final String title;
        public final int plays;
        public final long time;

        public SongStat(String title, int plays, long time) {
            this.title = title;
            this.plays = plays;
            this.time = time;
        }
    }

    // Scrollable stats list widget
    public class StatsListWidget extends ObjectSelectionList<StatsEntry> {
        public StatsListWidget(Minecraft minecraft, int width, int height, int y, int itemHeight) {
            super(minecraft, width, height, y, itemHeight);
        }

        public void clear() {
            this.clearEntries();
        }

        @Override
        public int addEntry(StatsEntry entry) {
            return super.addEntry(entry);
        }

        @Override
        public int getRowWidth() {
            return this.width - 10;
        }

        @Override
        protected int scrollBarX() {
            return this.getX() + this.width - 6;
        }
    }

    // Individual stat entries in the list
    public class StatsEntry extends ObjectSelectionList.Entry<StatsEntry> {
        private final String title;
        private final String timeStr;
        private final int plays;

        public StatsEntry(String title, String timeStr, int plays) {
            this.title = title;
            this.timeStr = timeStr;
            this.plays = plays;
        }

        @Override
        public Component getNarration() {
            return Component.literal(title);
        }

        @Override
        public void extractContent(GuiGraphicsExtractor graphics, int entryIndex, int top, boolean isSelected, float partialTick) {
            int left = this.getX();
            int y = this.getY();
            int entryWidth = this.getWidth();
            int entryHeight = this.getHeight();

            int bgColor = (entryIndex % 2 == 0) ? 0x20FFFFFF : 0x10FFFFFF;
            graphics.fill(left, y, left + entryWidth, y + entryHeight, bgColor);

            // Render song title
            String displayTitle = title;
            int maxTitleWidth = 180;
            if (font.width(displayTitle) > maxTitleWidth) {
                displayTitle = font.plainSubstrByWidth(displayTitle, maxTitleWidth - 10) + "...";
            }
            graphics.text(font, displayTitle, left + 6, y + 4, 0xFFFFFFFF, true);

            // Render time
            graphics.text(font, timeStr, left + 200, y + 4, 0xFF55FFFF, true);

            // Render play count
            String playsStr = String.valueOf(plays);
            graphics.text(font, playsStr, left + 290, y + 4, 0xFF55FF55, true);
        }
    }
}
