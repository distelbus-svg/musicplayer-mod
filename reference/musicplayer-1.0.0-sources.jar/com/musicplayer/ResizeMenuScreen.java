package com.musicplayer;

import com.musicplayer.config.MusicPlayerConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.MouseButtonEvent;

public class ResizeMenuScreen extends Screen {
    private final Screen parent;
    private float currentScale = 1.0f;
    
    // Dragging state
    private boolean isDraggingCorner = false;
    private int dragStartX = 0;
    private float dragStartScale = 1.0f;

    public ResizeMenuScreen(Screen parent) {
        super(Component.literal("Resize Menu"));
        this.parent = parent;
        this.currentScale = MusicPlayerConfig.getInstance().getGuiScale();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        // Done button at the bottom of the screen
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> {
            MusicPlayerConfig.getInstance().setGuiScale(currentScale);
            this.onClose();
        }).bounds(centerX - 50, this.height - 30, 100, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        this.extractMenuBackground(graphics);

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        // Draw top screen title
        graphics.centeredText(this.font, this.title, centerX, 15, 0xFFFFFFFF);
        graphics.centeredText(this.font, String.format("Current Scale: %.2fx (Drag corner to change)", currentScale), centerX, 30, 0xFFAAAAAA);

        // Render mock player GUI window that dynamically scales
        int baseWidth = 160;
        int baseHeight = 110;
        int mockWidth = (int) (baseWidth * currentScale);
        int mockHeight = (int) (baseHeight * currentScale);

        int mockLeft = centerX - mockWidth / 2;
        int mockTop = centerY - mockHeight / 2 - 10;
        int mockRight = mockLeft + mockWidth;
        int mockBottom = mockTop + mockHeight;

        // Mock window panel
        graphics.fill(mockLeft - 2, mockTop - 2, mockRight + 2, mockBottom + 2, 0xFF3C3C3C);
        graphics.fill(mockLeft, mockTop, mockRight, mockBottom, 0xFF2D2D2D);
        graphics.fill(mockLeft, mockTop, mockRight, mockTop + (int)(15 * currentScale), 0xFF383838); // Titlebar

        // Mock controls & texts
        graphics.centeredText(this.font, "Mock Player Window", centerX, mockTop + (int)(4 * currentScale), 0xFFFFFFFF);
        graphics.fill(mockLeft + (int)(8 * currentScale), mockTop + (int)(20 * currentScale), mockRight - (int)(8 * currentScale), mockBottom - (int)(30 * currentScale), 0x30FFFFFF); // List area
        graphics.centeredText(this.font, "Song Item 1", centerX, mockTop + (int)(24 * currentScale), 0xFFAAAAAA);
        graphics.centeredText(this.font, "Song Item 2", centerX, mockTop + (int)(38 * currentScale), 0xFFAAAAAA);

        // Mock Playback buttons row
        int btnSize = (int) (12 * currentScale);
        int btnY = mockBottom - (int)(18 * currentScale);
        graphics.fill(mockLeft + (int)(10 * currentScale), btnY, mockLeft + (int)(10 * currentScale) + btnSize, btnY + btnSize, 0xFF555555);
        graphics.fill(mockLeft + (int)(25 * currentScale), btnY, mockLeft + (int)(25 * currentScale) + btnSize, btnY + btnSize, 0xFF00AA00);
        graphics.fill(mockLeft + (int)(40 * currentScale), btnY, mockLeft + (int)(40 * currentScale) + btnSize, btnY + btnSize, 0xFF555555);

        // Drag handle at bottom-right corner
        int handleSize = 10;
        int handleLeft = mockRight - handleSize;
        int handleTop = mockBottom - handleSize;
        
        boolean hovered = mouseX >= handleLeft && mouseX <= mockRight && mouseY >= handleTop && mouseY <= mockBottom;
        int handleColor = (hovered || isDraggingCorner) ? 0xFFFF5555 : 0xFFAAAAAA;

        // Draw professional striped drag corner handle
        graphics.fill(handleLeft, handleTop, mockRight, mockBottom, handleColor);
        graphics.fill(handleLeft + 2, handleTop + 2, mockRight - 2, mockBottom - 2, 0xFF2D2D2D);
        
        // Corner diagonals
        graphics.fill(mockRight - 4, mockBottom - 2, mockRight - 2, mockBottom - 4, handleColor);
        graphics.fill(mockRight - 7, mockBottom - 2, mockRight - 2, mockBottom - 7, handleColor);

        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean isFocused) {
        if (event.buttonInfo().button() == 0) {
            int centerX = this.width / 2;
            int centerY = this.height / 2;
            int baseWidth = 160;
            int mockWidth = (int) (baseWidth * currentScale);
            int mockLeft = centerX - mockWidth / 2;
            int mockRight = mockLeft + mockWidth;
            int mockHeight = (int) (110 * currentScale);
            int mockTop = centerY - mockHeight / 2 - 10;
            int mockBottom = mockTop + mockHeight;

            int handleSize = 10;
            int handleLeft = mockRight - handleSize;
            int handleTop = mockBottom - handleSize;

            double mouseX = event.x();
            double mouseY = event.y();

            if (mouseX >= handleLeft && mouseX <= mockRight && mouseY >= handleTop && mouseY <= mockBottom) {
                isDraggingCorner = true;
                dragStartX = (int) mouseX;
                dragStartScale = currentScale;
                return true;
            }
        }
        return super.mouseClicked(event, isFocused);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.buttonInfo().button() == 0) {
            isDraggingCorner = false;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (isDraggingCorner) {
            int deltaX = (int) (event.x() - dragStartX);
            // Every 60 pixels of dragging represents 0.5x scale change
            float scaleDelta = (float) deltaX / 60.0f;
            currentScale = Math.max(0.8f, Math.min(2.0f, dragStartScale + scaleDelta));
            
            // Round to nearest 0.05 for clean Scaling increments
            currentScale = Math.round(currentScale * 20.0f) / 20.0f;
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
