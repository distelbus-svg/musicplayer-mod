package com.musicplayer;

import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.util.RandomSource;

public class ModSoundInstance extends SimpleSoundInstance {

    public ModSoundInstance(SoundEvent soundEvent) {
        super(
            soundEvent.location(),
            SoundSource.RECORDS,
            1.0f,
            1.0f,
            RandomSource.create(),
            false,
            0,
            SoundInstance.Attenuation.NONE,
            0.0D,
            0.0D,
            0.0D,
            true
        );
    }

    @Override
    public float getVolume() {
        if (MusicPlayerManager.getInstance().getEngine() == null) {
            return 0.0f;
        }
        float engineVol = MusicPlayerManager.getInstance().getEngine().getVolume();
        float engineFade = MusicPlayerManager.getInstance().getEngine().getFadeVolume();
        return engineVol * engineFade;
    }
}
