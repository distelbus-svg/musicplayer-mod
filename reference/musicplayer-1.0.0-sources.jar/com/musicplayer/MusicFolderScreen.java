package com.musicplayer;

import com.musicplayer.notification.NotificationManager;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.File;

/**
 * Sub-screen for setting the music folder path.
 * Extracted from the original MusicSettingsScreen.
 */
public class MusicFolderScreen extends ScaledScreen {

    private final Screen parent;
    private final MusicPlayerManager manager;
    private EditBox folderInput;
    private Component statusMessage = Component.empty();
    private int statusColor = 0xFFFFFFFF;

    public MusicFolderScreen(Screen parent) {
        super(Component.literal("Set Music Folder Path"));
        this.parent = parent;
        this.manager = MusicPlayerManager.getInstance();
    }

    @Override
    protected void initScaled() {
        int centerX = this.width / 2;
        int panelWidth = 280;
        int panelLeft = centerX - panelWidth / 2;
        int panelTop = this.height / 2 - 60;

        // Folder path input
        folderInput = new EditBox(
                this.font,
                panelLeft + 10, panelTop + 35,
                panelWidth - 80, 20,
                Component.literal("Music Folder Path")
        );
        folderInput.setMaxLength(512);
        folderInput.setValue(manager.getConfig().getMusicFolderPath());
        addRenderableWidget(folderInput);

        // Set button
        addRenderableWidget(Button.builder(Component.literal("Set"), button -> {
            String path = folderInput.getValue().trim();
            if (path.isEmpty()) {
                statusMessage = Component.literal("Please enter a folder path");
                statusColor = 0xFFFF5555;
                return;
            }
            File folder = new File(path);
            if (!folder.exists()) {
                statusMessage = Component.literal("Folder does not exist!");
                statusColor = 0xFFFF5555;
            } else if (!folder.isDirectory()) {
                statusMessage = Component.literal("Path is not a folder!");
                statusColor = 0xFFFF5555;
            } else {
                manager.setMusicFolder(path);
                int count = manager.getPlaylist().size();
                statusMessage = Component.literal("Loaded " + count + " songs!");
                statusColor = 0xFF55FF55;

                // Auto-create playlist
                if (count > 0) {
                    String folderName = folder.getName();
                    Playlist autoPlaylist = new Playlist(folderName);
                    for (SongInfo song : manager.getPlaylist()) {
                        autoPlaylist.addSong(song);
                    }
                    PlaylistManager.getInstance().savePlaylist(autoPlaylist);
                    statusMessage = Component.literal("Playlist '" + folderName + "' created!");
                    NotificationManager.showSystem("Playlist '" + folderName + "' created!");
                }
            }
        }).bounds(panelLeft + panelWidth - 60, panelTop + 35, 50, 20).build());

        // Browse button
        addRenderableWidget(Button.builder(Component.literal("Browse..."), button -> {
            if (this.minecraft.getWindow().isFullscreen()) {
                statusMessage = Component.literal("Please exit Fullscreen to use File Browser (macOS bug)");
                statusColor = 0xFFFF5555;
                return;
            }
            String initialPath = manager.getConfig().getMusicFolderPath();
            if (initialPath.isEmpty()) {
                initialPath = System.getProperty("user.home");
            }
            String result = TinyFileDialogs.tinyfd_selectFolderDialog("Select Music Folder", initialPath);
            if (result != null) {
                folderInput.setValue(result);
            }
        }).bounds(panelLeft + 10, panelTop + 60, 80, 20).build());

        // Done button
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> {
            this.onClose();
        }).bounds(centerX - 50, panelTop + 100, 100, 20).build());
    }

    @Override
    public void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0xC0000000);

        int centerX = this.width / 2;
        int panelWidth = 280;
        int panelLeft = centerX - panelWidth / 2;
        int panelTop = this.height / 2 - 60;
        int panelBottom = panelTop + 120;

        // Panel background
        graphics.fill(panelLeft - 2, panelTop - 2, panelLeft + panelWidth + 2, panelBottom + 2, 0xFF555555);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelBottom, 0xFF2D2D2D);

        // Title
        graphics.centeredText(this.font, this.title, centerX, panelTop + 8, 0xFFFFFFFF);

        // Label
        graphics.text(this.font, "Music Folder:", panelLeft + 10, panelTop + 25, 0xFFAAAAAA, true);

        // Status message
        if (statusMessage != Component.empty()) {
            graphics.centeredText(this.font, statusMessage, centerX, panelTop + 85, statusColor);
        }

        super.renderScaled(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
