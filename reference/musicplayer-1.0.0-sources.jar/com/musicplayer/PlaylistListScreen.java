package com.musicplayer;

import com.musicplayer.widget.PlaylistListWidget;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class PlaylistListScreen extends ScaledScreen {
    private final Screen parent;
    private PlaylistListWidget list;
    private EditBox nameInput;

    public PlaylistListScreen(Screen parent) {
        super(Component.literal("Playlists"));
        this.parent = parent;
    }

    @Override
    protected void initScaled() {
        int panelWidth = 280;
        int panelHeight = 220;
        int panelLeft = (this.width - panelWidth) / 2;
        int panelTop = (this.height - panelHeight) / 2;

        // List
        list = new PlaylistListWidget(this.minecraft, panelWidth - 20, panelHeight - 80, panelTop + 30, 24);
        list.setX(panelLeft + 10);
        list.setY(panelTop + 30);
        list.refreshEntries(this::playPlaylist, this::editPlaylist, this::deletePlaylist);
        addRenderableWidget(list);

        // New playlist input
        nameInput = new EditBox(this.font, panelLeft + 10, panelTop + panelHeight - 45, 160, 20, Component.literal("Name"));
        addRenderableWidget(nameInput);

        // Create button
        addRenderableWidget(Button.builder(Component.literal("Create"), button -> {
            String name = nameInput.getValue().trim();
            if (!name.isEmpty()) {
                Playlist p = new Playlist(name);
                PlaylistManager.getInstance().savePlaylist(p);
                nameInput.setValue("");
                list.refreshEntries(this::playPlaylist, this::editPlaylist, this::deletePlaylist);
            }
        }).bounds(panelLeft + 175, panelTop + panelHeight - 45, 60, 20).build());

        // Main Library button
        addRenderableWidget(Button.builder(Component.literal("Main Library"), button -> {
            MusicPlayerManager.getInstance().switchToMainLibrary();
            this.minecraft.setScreen(parent);
        }).bounds(panelLeft + 10, panelTop + panelHeight - 22, 100, 20).build());

        // Back button
        addRenderableWidget(Button.builder(Component.literal("Back"), button -> {
            this.minecraft.setScreen(parent);
        }).bounds(panelLeft + panelWidth - 50, panelTop + panelHeight - 22, 40, 20).build());
    }

    private void playPlaylist(Playlist p) {
        MusicPlayerManager.getInstance().loadCustomPlaylist(p);
        this.minecraft.setScreen(parent);
    }

    private void editPlaylist(Playlist p) {
        this.minecraft.setScreen(new PlaylistEditScreen(this, p));
    }

    private void deletePlaylist(Playlist p) {
        PlaylistManager.getInstance().deletePlaylist(p);
        list.refreshEntries(this::playPlaylist, this::editPlaylist, this::deletePlaylist);
    }

    @Override
    public void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        this.extractMenuBackground(graphics);
        int panelWidth = 280;
        int panelHeight = 220;
        int panelLeft = (this.width - panelWidth) / 2;
        int panelTop = (this.height - panelHeight) / 2;

        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, 0xDD222222);
        graphics.centeredText(this.font, "My Playlists", panelLeft + panelWidth / 2, panelTop + 10, 0xFFFFFFFF);
        
        super.renderScaled(graphics, mouseX, mouseY, partialTick);
    }
}
