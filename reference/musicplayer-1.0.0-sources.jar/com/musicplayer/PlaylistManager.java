package com.musicplayer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles persistence and management of playlists.
 * Playlists are stored in .minecraft/config/musicplayer/playlists/
 */
public class PlaylistManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PLAYLISTS_DIR = FabricLoader.getInstance().getConfigDir().resolve("musicplayer").resolve("playlists");

    private final List<Playlist> playlists = new ArrayList<>();
    private static PlaylistManager instance;

    private PlaylistManager() {
        loadAll();
    }

    public static PlaylistManager getInstance() {
        if (instance == null) {
            instance = new PlaylistManager();
        }
        return instance;
    }

    private void loadAll() {
        playlists.clear();
        if (!Files.exists(PLAYLISTS_DIR)) {
            try {
                Files.createDirectories(PLAYLISTS_DIR);
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        }

        try {
            List<Path> files = Files.list(PLAYLISTS_DIR)
                    .filter(p -> p.toString().endsWith(".json"))
                    .collect(Collectors.toList());

            for (Path file : files) {
                try (Reader reader = Files.newBufferedReader(file)) {
                    Playlist playlist = GSON.fromJson(reader, Playlist.class);
                    if (playlist != null) {
                        // Migration from old format
                        if (playlist.getSongs().isEmpty() && playlist.getLegacyPaths() != null) {
                            for (String path : playlist.getLegacyPaths()) {
                                File f = new File(path);
                                if (f.exists()) {
                                    playlist.addSong(SongInfo.fromFile(f));
                                }
                            }
                            savePlaylist(playlist); // Save converted version
                        }
                        playlists.add(playlist);
                    }
                } catch (Exception e) {
                    System.err.println("Failed to load playlist: " + file);
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        generateDefaultPlaylists();
    }

    public static String cleanMinecraftSoundName(String rawId) {
        String path = rawId;
        if (path.contains(":")) {
            path = path.substring(path.indexOf(":") + 1);
        }
        if (path.startsWith("music.")) {
            path = path.substring("music.".length());
        }
        if (path.startsWith("music_disc.")) {
            path = path.substring("music_disc.".length());
        }
        if (path.startsWith("music_disc_")) {
            path = path.substring("music_disc_".length());
        }
        
        // Capitalize words
        String[] parts = path.split("[._]");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(" ");
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    private void generateDefaultPlaylists() {
        boolean hasMinecraftMusic = playlists.stream().anyMatch(p -> p.getName().equals("Minecraft Music"));
        if (hasMinecraftMusic) {
            Playlist pm = playlists.stream().filter(p -> p.getName().equals("Minecraft Music")).findFirst().get();
            if (pm.getSongs().stream().anyMatch(s -> s.getTitle().startsWith("minecraft:"))) {
                deletePlaylist(pm);
                hasMinecraftMusic = false;
            }
        }
        if (!hasMinecraftMusic) {
            Playlist mcMusic = new Playlist("Minecraft Music");
            for (Identifier id : BuiltInRegistries.SOUND_EVENT.keySet()) {
                if (id.getPath().startsWith("music.") || id.getPath().startsWith("music_disc.")) {
                    String title = cleanMinecraftSoundName(id.toString());
                    SongInfo info = new SongInfo(title, "Minecraft", id.toString(), SongInfo.SourceType.MINECRAFT_MUSIC);
                    mcMusic.addSong(info);
                }
            }
            if (!mcMusic.getSongs().isEmpty()) {
                playlists.add(mcMusic);
                savePlaylist(mcMusic);
            }
        }

        boolean hasMusicDiscs = playlists.stream().anyMatch(p -> p.getName().equals("Music Discs"));
        if (hasMusicDiscs) {
            Playlist pm = playlists.stream().filter(p -> p.getName().equals("Music Discs")).findFirst().get();
            if (pm.getSongs().stream().allMatch(s -> s.getTitle().equals("Music Disc"))
                || pm.getSongs().stream().anyMatch(s -> s.getPath().contains("music_disc_"))) {
                deletePlaylist(pm);
                hasMusicDiscs = false;
            }
        }
        if (!hasMusicDiscs) {
            Playlist discs = new Playlist("Music Discs");
            for (Item item : BuiltInRegistries.ITEM) {
                if (item != null && item.components().has(DataComponents.JUKEBOX_PLAYABLE)) {
                    Identifier id = BuiltInRegistries.ITEM.getKey(item);
                    String soundPath = id.toString();
                    if (soundPath.contains("music_disc_")) {
                        soundPath = soundPath.replace("music_disc_", "music_disc.");
                    }
                    String title = cleanMinecraftSoundName(id.toString());
                    SongInfo info = new SongInfo(title, "Minecraft", soundPath, SongInfo.SourceType.DISC);
                    discs.addSong(info);
                }
            }
            if (!discs.getSongs().isEmpty()) {
                playlists.add(discs);
                savePlaylist(discs);
            }
        }
    }

    public void savePlaylist(Playlist playlist) {
        String fileName = playlist.getName().replaceAll("[^a-zA-Z0-9.-]", "_") + ".json";
        Path path = PLAYLISTS_DIR.resolve(fileName);

        try (Writer writer = Files.newBufferedWriter(path)) {
            GSON.toJson(playlist, writer);
            if (!playlists.contains(playlist)) {
                playlists.add(playlist);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void deletePlaylist(Playlist playlist) {
        String fileName = playlist.getName().replaceAll("[^a-zA-Z0-9.-]", "_") + ".json";
        Path path = PLAYLISTS_DIR.resolve(fileName);
        try {
            Files.deleteIfExists(path);
            playlists.remove(playlist);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void rename(Playlist playlist, String newName) {
        deletePlaylist(playlist);
        playlist.setName(newName);
        savePlaylist(playlist);
    }

    public List<Playlist> getPlaylists() {
        return playlists;
    }

    public void reload() {
        loadAll();
    }
}
