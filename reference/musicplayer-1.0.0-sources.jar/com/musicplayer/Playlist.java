package com.musicplayer;

import java.util.ArrayList;
import java.util.List;

/**
 * Data class representing a music playlist.
 */
public class Playlist {
    private String name;
    private final List<SongInfo> songs;
    private List<String> songPaths; // Legacy support for migration

    public Playlist(String name) {
        this.name = name;
        this.songs = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<SongInfo> getSongs() {
        return songs;
    }

    public void addSong(SongInfo song) {
        // Check for duplicates by path
        for (SongInfo s : songs) {
            if (s.getPath().equals(song.getPath())) return;
        }
        songs.add(song);
    }

    public void removeSong(SongInfo song) {
        songs.remove(song);
    }

    public List<String> getLegacyPaths() {
        return songPaths;
    }
}
