package com.musicplayer;

import com.musicplayer.config.MusicPlayerConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.MouseButtonEvent;

public abstract class ScaledScreen extends Screen {
    protected ScaledScreen(Component title) {
        super(title);
    }

    protected float getScale() {
        return MusicPlayerConfig.getInstance().getGuiScale();
    }

    @Override
    protected void init() {
        float scale = getScale();
        int oldWidth = this.width;
        int oldHeight = this.height;
        
        // Scale dimensions dynamically for child coordinates initialization
        this.width = (int) (oldWidth / scale);
        this.height = (int) (oldHeight / scale);
        
        initScaled();
        
        this.width = oldWidth;
        this.height = oldHeight;
    }

    protected abstract void initScaled();

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        float scale = getScale();
        if (scale != 1.0f) {
            graphics.pose().pushMatrix();
            graphics.pose().scale(scale, scale);
        }
        
        int scaledMouseX = (int) (mouseX / scale);
        int scaledMouseY = (int) (mouseY / scale);
        
        renderScaled(graphics, scaledMouseX, scaledMouseY, partialTick);
        
        if (scale != 1.0f) {
            graphics.pose().popMatrix();
        }
    }

    protected void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean isFocused) {
        float scale = getScale();
        if (scale != 1.0f) {
            MouseButtonEvent scaledEvent = new MouseButtonEvent(
                event.x() / scale,
                event.y() / scale,
                event.buttonInfo()
            );
            return super.mouseClicked(scaledEvent, isFocused);
        }
        return super.mouseClicked(event, isFocused);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        float scale = getScale();
        if (scale != 1.0f) {
            MouseButtonEvent scaledEvent = new MouseButtonEvent(
                event.x() / scale,
                event.y() / scale,
                event.buttonInfo()
            );
            return super.mouseReleased(scaledEvent);
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        float scale = getScale();
        if (scale != 1.0f) {
            MouseButtonEvent scaledEvent = new MouseButtonEvent(
                event.x() / scale,
                event.y() / scale,
                event.buttonInfo()
            );
            return super.mouseDragged(scaledEvent, dragX / scale, dragY / scale);
        }
        return super.mouseDragged(event, dragX, dragY);
    }
}
