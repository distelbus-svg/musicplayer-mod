package com.musicplayer;

import com.musicplayer.config.MusicPlayerConfig;
import com.musicplayer.config.MusicPlayerConfig.PlaybackMode;
import com.musicplayer.widget.ProgressBarWidget;
import com.musicplayer.widget.SongListWidget;
import com.musicplayer.widget.VolumeSliderWidget;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.File;

/**
 * The main music player GUI screen with song list, playback controls,
 * progress bar, volume slider, and playback mode buttons.
 * Styled to match Minecraft's vanilla UI aesthetic.
 */
public class MusicPlayerScreen extends ScaledScreen {

    private final MusicPlayerManager manager;
    private SongListWidget songList;
    private ProgressBarWidget progressBar;
    private VolumeSliderWidget volumeSlider;

    private Button playPauseButton;
    private Button shuffleButton;
    private Button repeatButton;

    // Layout constants
    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelHeight;

    public MusicPlayerScreen() {
        super(Component.literal("\u266B Music Player"));
        this.manager = MusicPlayerManager.getInstance();
    }

    @Override
    protected void initScaled() {
        // Ensure playlist is loaded
        if (!manager.isLoaded()) {
            manager.reloadLibraryFromDisk();
        }

        // Panel dimensions - centered on screen
        panelWidth = Math.min(340, this.width - 40);
        panelHeight = Math.min(260, this.height - 40);
        panelLeft = (this.width - panelWidth) / 2;
        panelTop = (this.height - panelHeight) / 2;

        int contentLeft = panelLeft + 8;
        int contentWidth = panelWidth - 16;

        // ---- Title bar buttons ----
        int titleBarY = panelTop + 4;

        // Settings gear button (top-right area)
        addRenderableWidget(Button.builder(Component.literal("\u2699"), button -> {
            this.minecraft.setScreen(new MusicSettingsScreen(this));
        }).bounds(panelLeft + panelWidth - 44, titleBarY, 18, 18).build());

        // Playlists button
        addRenderableWidget(Button.builder(Component.literal("\u2630"), button -> {
            this.minecraft.setScreen(new PlaylistListScreen(this));
        }).bounds(panelLeft + panelWidth - 66, titleBarY, 18, 18).build());

        // Close button
        addRenderableWidget(Button.builder(Component.literal("X"), button -> {
            this.onClose();
        }).bounds(panelLeft + panelWidth - 22, titleBarY, 18, 18).build());

        // ---- Song list ----
        int listTop = panelTop + 26;
        int listHeight = panelHeight - 130; // Increased spacing
        songList = new SongListWidget(this.minecraft, contentWidth, listHeight, listTop, 16);
        songList.setX(contentLeft);
        songList.setY(listTop); // Explicitly set Y
        songList.setSongs(manager.getPlaylist());
        addRenderableWidget(songList);

        SongInfo currentSongInit = manager.getCurrentSong();
        if (currentSongInit != null) {
            int index = 0;
            for (SongListWidget.SongEntry entry : songList.children()) {
                if (entry.getSong().getPath().equals(currentSongInit.getPath())) {
                    songList.setSelected(entry);
                    songList.setScrollAmount(index * 16);
                    break;
                }
                index++;
            }
        }

        // ---- Bottom controls area ----
        int controlsTop = panelTop + panelHeight - 85;

        // Progress bar
        progressBar = new ProgressBarWidget(contentLeft, controlsTop + 23, contentWidth, 12);
        addRenderableWidget(progressBar);

        // ---- Playback buttons row ----
        int btnY = controlsTop + 49;
        int btnSize = 20;
        int totalBtnWidth = btnSize * 5 + 4 * 4; // 5 buttons with 4px gaps
        int btnStartX = contentLeft + (contentWidth - totalBtnWidth - 80) / 2; // leave room for volume

        // Previous track
        addRenderableWidget(Button.builder(Component.literal("\u23EE"), button -> {
            manager.previousTrack();
        }).bounds(btnStartX, btnY, btnSize, btnSize).build());

        // Play/Pause
        playPauseButton = Button.builder(Component.literal("\u25B6"), button -> {
            manager.togglePlayPause();
        }).bounds(btnStartX + btnSize + 4, btnY, btnSize, btnSize).build();
        addRenderableWidget(playPauseButton);

        // Next track
        addRenderableWidget(Button.builder(Component.literal("\u23ED"), button -> {
            manager.nextTrack();
        }).bounds(btnStartX + (btnSize + 4) * 2, btnY, btnSize, btnSize).build());

        // Shuffle button
        shuffleButton = Button.builder(Component.literal("\u21C6"), button -> {
            PlaybackMode mode = manager.getConfig().getPlaybackMode();
            if (mode == PlaybackMode.SHUFFLE) {
                manager.setPlaybackMode(PlaybackMode.SEQUENTIAL);
            } else {
                manager.setPlaybackMode(PlaybackMode.SHUFFLE);
            }
        }).bounds(btnStartX + (btnSize + 4) * 3, btnY, btnSize, btnSize).build();
        addRenderableWidget(shuffleButton);

        // Repeat button
        repeatButton = Button.builder(Component.literal("\u21BB"), button -> {
            PlaybackMode mode = manager.getConfig().getPlaybackMode();
            if (mode == PlaybackMode.REPEAT_ALL) {
                manager.setPlaybackMode(PlaybackMode.REPEAT_ONE);
            } else if (mode == PlaybackMode.REPEAT_ONE) {
                manager.setPlaybackMode(PlaybackMode.SEQUENTIAL);
            } else {
                manager.setPlaybackMode(PlaybackMode.REPEAT_ALL);
            }
        }).bounds(btnStartX + (btnSize + 4) * 4, btnY, btnSize, btnSize).build();
        addRenderableWidget(repeatButton);

        // Volume slider (right side of controls)
        int volWidth = 70;
        int volX = contentLeft + contentWidth - volWidth;
        volumeSlider = new VolumeSliderWidget(volX, btnY + 4, volWidth, 12);
        addRenderableWidget(volumeSlider);
    }

    @Override
    public void renderScaled(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // Darken background
        graphics.fill(0, 0, this.width, this.height, 0x90000000);

        // Panel border (slightly lighter for Minecraft button-style look)
        graphics.fill(panelLeft - 2, panelTop - 2, panelLeft + panelWidth + 2, panelTop + panelHeight + 2, 0xFF3C3C3C);
        // Panel inner border highlight (top/left lighter, bottom/right darker - MC button style)
        graphics.fill(panelLeft - 1, panelTop - 1, panelLeft + panelWidth + 1, panelTop, 0xFF6E6E6E);
        graphics.fill(panelLeft - 1, panelTop - 1, panelLeft, panelTop + panelHeight + 1, 0xFF6E6E6E);
        graphics.fill(panelLeft + panelWidth, panelTop, panelLeft + panelWidth + 1, panelTop + panelHeight + 1, 0xFF1E1E1E);
        graphics.fill(panelLeft, panelTop + panelHeight, panelLeft + panelWidth + 1, panelTop + panelHeight + 1, 0xFF1E1E1E);
        // Panel background
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, 0xFF2D2D2D);

        // Title bar background
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 24, 0xFF383838);
        // Title bar bottom border
        graphics.fill(panelLeft, panelTop + 23, panelLeft + panelWidth, panelTop + 24, 0xFF555555);

        // Title text
        graphics.text(this.font, this.title, panelLeft + 8, panelTop + 8, 0xFFFFFFFF, true);

        // Environment header
        String playlistName = manager.isUsingCustomPlaylist() ? manager.getCurrentCustomPlaylist().getName() : "Main Library";
        String envHeader = playlistName;
        int titleWidth = this.font.width(this.title);
        int maxEnvWidth = panelWidth - 44 - (8 + titleWidth + 10);
        if (this.font.width(envHeader) > maxEnvWidth) {
            envHeader = this.font.plainSubstrByWidth(envHeader, maxEnvWidth - 10) + "...";
        }
        graphics.text(this.font, envHeader, panelLeft + 8 + titleWidth + 10, panelTop + 8, 0xFFAAAAAA, true);

        // ---- Now Playing section ----
        int controlsTop = panelTop + panelHeight - 85;

        // Separator line above controls
        graphics.fill(panelLeft + 4, controlsTop - 2, panelLeft + panelWidth - 4, controlsTop - 1, 0xFF555555);

        // "Now Playing" text
        SongInfo currentSong = manager.getCurrentSong();
        String nowPlaying;
        if (currentSong != null && manager.getEngine().isActive()) {
            nowPlaying = "Now Playing: " + currentSong.getTitle();
        } else {
            nowPlaying = "No song playing";
        }

        // Truncate if too long
        int contentWidth = panelWidth - 16;
        String displayText = nowPlaying;
        while (this.font.width(displayText) > contentWidth - 4 && displayText.length() > 3) {
            displayText = displayText.substring(0, displayText.length() - 4) + "...";
        }
        graphics.text(this.font, displayText, panelLeft + 8, controlsTop + 4, 0xFF55FF55, true);

        // Update play/pause button text
        if (manager.getEngine().isActive() && !manager.getEngine().isPaused()) {
            playPauseButton.setMessage(Component.literal("\u23F8")); // Pause icon
        } else {
            playPauseButton.setMessage(Component.literal("\u25B6")); // Play icon
        }

        // Update shuffle button visual feedback
        PlaybackMode mode = manager.getConfig().getPlaybackMode();
        // We'll show mode-specific text for the repeat button
        if (mode == PlaybackMode.REPEAT_ONE) {
            repeatButton.setMessage(Component.literal("\u21BB1"));
        } else {
            repeatButton.setMessage(Component.literal("\u21BB"));
        }

        // Playback mode label
        String modeLabel = switch (mode) {
            case SEQUENTIAL -> "";
            case SHUFFLE -> "\u21C6 Shuffle";
            case REPEAT_ALL -> "\u21BB Repeat All";
            case REPEAT_ONE -> "\u21BB Repeat One";
        };
        if (!modeLabel.isEmpty()) {
            int modeLabelWidth = this.font.width(modeLabel);
            graphics.text(this.font, modeLabel,
                    panelLeft + panelWidth - 8 - modeLabelWidth,
                    controlsTop + 4,
                    0xFFAAAA55, true);
        }

        // Volume label
        int volPercent = Math.round(manager.getEngine().getVolume() * 100);
        String volLabel = "Vol";
        int volX = panelLeft + panelWidth - 16 - 70;
        int btnY = controlsTop + 49;
        graphics.text(this.font, volLabel, volX - this.font.width(volLabel) - 4, btnY + 6, 0xFFAAAAAA, true);

        // Empty playlist hint
        if (manager.getPlaylist().isEmpty()) {
            String hint = manager.getConfig().getMusicFolderPath().isEmpty()
                    ? "Click \u2699 to set your music folder"
                    : "No MP3/WAV files found in folder";
            graphics.centeredText(this.font, hint,
                    panelLeft + panelWidth / 2,
                    panelTop + 26 + (panelHeight - 120) / 2,
                    0xFF888888);
        }

        super.renderScaled(graphics, mouseX, mouseY, partialTick);
    }

    /**
     * Refreshes the song list (called after settings change the folder).
     */
    public void refreshSongList() {
        if (songList != null) {
            songList.setSongs(manager.getPlaylist());
        }
    }

    @Override
    public boolean isPauseScreen() {
        return manager.getConfig().isPauseOnGamePause() && this.minecraft.isSingleplayer();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(null);
    }
}
